#include<SARM.H>
void FSMC_Init(void){
	GPIO_InitTypeDef gpio;
	FSMC_NORSRAMInitTypeDef ram;
	FSMC_NORSRAMTimingInitTypeDef read;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD|RCC_APB2Periph_GPIOE|RCC_APB2Periph_GPIOF|RCC_APB2Periph_GPIOG,ENABLE);
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_FSMC,ENABLE);
	gpio.GPIO_Speed=GPIO_Speed_50MHz;
	gpio.GPIO_Mode=GPIO_Mode_AF_PP;
	gpio.GPIO_Pin=GPIO_Pin_10;
	GPIO_Init(GPIOG,&gpio);
	
	gpio.GPIO_Pin=GPIO_Pin_0|GPIO_Pin_1;
	GPIO_Init(GPIOE,&gpio);
	
	gpio.GPIO_Pin=GPIO_Pin_4|GPIO_Pin_5;
	GPIO_Init(GPIOD,&gpio);
	
  gpio.GPIO_Pin =(GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_8| GPIO_Pin_9 | GPIO_Pin_10 |GPIO_Pin_11| GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14| GPIO_Pin_15 );
  GPIO_Init(GPIOD, &gpio);
	
	gpio.GPIO_Pin =(GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2| GPIO_Pin_3 | GPIO_Pin_4 |GPIO_Pin_5 | GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14| GPIO_Pin_15 );
	GPIO_Init(GPIOF, &gpio);
	
	gpio.GPIO_Pin =(GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2| GPIO_Pin_3 | GPIO_Pin_4 |GPIO_Pin_5);
	GPIO_Init(GPIOG, &gpio);
	
	read.FSMC_AddressSetupTime=0x00;
	read.FSMC_AddressHoldTime=0x00;
	read.FSMC_DataSetupTime=0x03;
	read.FSMC_BusTurnAroundDuration=0x00;
	read.FSMC_CLKDivision=0x00;
	read.FSMC_DataLatency=0x00;
	read.FSMC_AccessMode=FSMC_AccessMode_A;
	
	ram.FSMC_Bank=FSMC_Bank1_NORSRAM3;
	ram.FSMC_DataAddressMux=FSMC_DataAddressMux_Disable;
	ram.FSMC_MemoryType=FSMC_MemoryType_SRAM;
	ram.FSMC_MemoryDataWidth=FSMC_MemoryDataWidth_16b;
	ram.FSMC_BurstAccessMode=FSMC_BurstAccessMode_Disable;
	ram.FSMC_WaitSignalPolarity=FSMC_WaitSignalPolarity_Low;
	ram.FSMC_AsynchronousWait=FSMC_AsynchronousWait_Disable;
	ram.FSMC_WrapMode=FSMC_WrapMode_Disable;
	ram.FSMC_WaitSignalActive=FSMC_WaitSignalActive_BeforeWaitState;
	ram.FSMC_WriteOperation=FSMC_WriteOperation_Enable;
	ram.FSMC_WaitSignal=FSMC_WaitSignal_Disable;//Enable;
	ram.FSMC_ExtendedMode=FSMC_ExtendedMode_Disable;
	ram.FSMC_WriteBurst=FSMC_WriteBurst_Disable;
	ram.FSMC_ReadWriteTimingStruct=&read;
	ram.FSMC_WriteTimingStruct=&read;
	FSMC_NORSRAMInit(&ram);
	FSMC_NORSRAMCmd(FSMC_Bank1_NORSRAM3,ENABLE);
	
}
