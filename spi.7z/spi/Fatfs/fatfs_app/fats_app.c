#include	"fats_app.h"
#include "string.h"
#define FILE_MAX_TYPE_NUM		6	
#define FILE_MAX_SUBT_NUM		13	

 //�ļ������б�
u8*const FILE_TYPE_TBL[FILE_MAX_TYPE_NUM][FILE_MAX_SUBT_NUM]=
{
{"BIN"},			
{"LRC"},			
{"NES"},		
{"TXT","C","H"},	//�ı��ļ�
{"MP1","MP2","MP3","MP4","M4A","3GP","3G2","OGG","AAC","WMA","WAV","MID","FLAC"},
{"BMP","JPG","JPEG","GIF"},
};

FATFS *fs[_VOLUMES];
FIL *file;	  		
FIL *ftemp;	  		
UINT br,bw;			
FILINFO fileinfo;	
DIR dir;  			

u8 *fatbuf;		
u8 FATFS_Init(void)
{
	u8 i;
	for(i=0;i<_VOLUMES;i++)
	{
		fs[i]=(FATFS*)mymalloc(SRAMIN,sizeof(FATFS));
		if(!fs[i])break;
	}
	file=(FIL*)mymalloc(SRAMIN,sizeof(FIL));		
	ftemp=(FIL*)mymalloc(SRAMIN,sizeof(FIL));		
	fatbuf=(u8*)mymalloc(SRAMIN,512);				
	if(i==_VOLUMES&&file&&ftemp&&fatbuf)return 0; 
	else return 1;	
}


u8 char_upper(u8 c)
{
	if(c<'A')return c;
	if(c>='a')return c-0x20;
	else return c;
}	      

u8 f_typetell(u8 *fname)
{
	u8 tbuf[5];
	u8 *attr='\0';
	u8 i=0,j;
	while(i<250)
	{
		i++;
		if(*fname=='\0')break;
		fname++;
	}
	if(i==250)return 0XFF;
 	for(i=0;i<5;i++)
	{
		fname--;
		if(*fname=='.')
		{
			fname++;
			attr=fname;
			break;
		}
  	}
	strcpy((char *)tbuf,(const char*)attr);//copy
 	for(i=0;i<4;i++)tbuf[i]=char_upper(tbuf[i]);
	for(i=0;i<FILE_MAX_TYPE_NUM;i++)	
	{
		for(j=0;j<FILE_MAX_SUBT_NUM;j++)
		{
			if(*FILE_TYPE_TBL[i][j]==0)break;
			if(strcmp((const char *)FILE_TYPE_TBL[i][j],(const char *)tbuf)==0)
			{
				return (i<<4)|j;
			}
		}
	}
	return 0XFF;	 			   
}	 


u8 fatfs_getfree(u8 *drv,u32 *total,u32 *free)
{
	FATFS *fs1;
	u8 res;
    u32 fre_clust=0, fre_sect=0, tot_sect=0;

    res =(u32)f_getfree((const TCHAR*)drv, (DWORD*)&fre_clust, &fs1);
    if(res==0)
	{											   
	    tot_sect=(fs1->n_fatent-2)*fs1->csize;	
	    fre_sect=fre_clust*fs1->csize;				   
#if _MAX_SS!=512				  				
		tot_sect*=fs1->ssize/512;
		fre_sect*=fs1->ssize/512;
#endif	  
		*total=tot_sect>>1;
		*free=fre_sect>>1;	
 	}
	return res;
}


u8 fatfs_copy(u8(*fcpymsg)(u8*pname,u8 pct,u8 mode),u8 *psrc,u8 *pdst,u32 totsize,u32 cpdsize,u8 fwmode)
{
	u8 res;
    u16 br=0;
	u16 bw=0;
	FIL *fsrc=0;
	FIL *fdst=0;
	u8 *fbuf=0;
	u8 curpct=0;
	unsigned long long lcpdsize=cpdsize; 
 	fsrc=(FIL*)mymalloc(SRAMIN,sizeof(FIL));
 	fdst=(FIL*)mymalloc(SRAMIN,sizeof(FIL));
	fbuf=(u8*)mymalloc(SRAMIN,8192);
  	if(fsrc==NULL||fdst==NULL||fbuf==NULL)res=100;
	else
	{   
		if(fwmode==0)fwmode=FA_CREATE_NEW;
		else fwmode=FA_CREATE_ALWAYS;	  
		 
	 	res=f_open(fsrc,(const TCHAR*)psrc,FA_READ|FA_OPEN_EXISTING);	
	 	if(res==0)res=f_open(fdst,(const TCHAR*)pdst,FA_WRITE|fwmode); 
		if(res==0)
		{
			if(totsize==0)
			{
				totsize=fsrc->obj.objsize;
				lcpdsize=0;
				curpct=0;
		 	}else curpct=(lcpdsize*100)/totsize;	
			fcpymsg(psrc,curpct,0X02);		
			while(res==0)
			{
				res=f_read(fsrc,fbuf,8192,(UINT*)&br);	
				if(res||br==0)break;
				res=f_write(fdst,fbuf,(UINT)br,(UINT*)&bw);	
				lcpdsize+=bw;
				if(curpct!=(lcpdsize*100)/totsize)
				{
					curpct=(lcpdsize*100)/totsize;
					if(fcpymsg(psrc,curpct,0X02))
					{
						res=0XFF;
						break;
					}
				}			     
				if(res||bw<br)break;       
			}
		    f_close(fsrc);
		    f_close(fdst);
		}
	}
	myfree(SRAMIN,fsrc);
	myfree(SRAMIN,fdst);
	myfree(SRAMIN,fbuf);
	return res;
}


u8* fatfs_get_src_dname(u8* dpfn)
{
	u16 temp=0;
 	while(*dpfn!=0)
	{
		dpfn++;
		temp++;	
	}
	if(temp<4)return 0; 
	while((*dpfn!=0x5c)&&(*dpfn!=0x2f))dpfn--;	
	return ++dpfn;
}

u32 fatfs_fdsize(u8 *fdname)
{
#define MAX_PATHNAME_DEPTH	512+1	
	u8 res=0;	  
    DIR *fddir=0;		
	FILINFO *finfo=0;	
	u8 * pathname=0;	
 	u16 pathlen=0;		
	u32 fdsize=0;

	fddir=(DIR*)mymalloc(SRAMIN,sizeof(DIR));
 	finfo=(FILINFO*)mymalloc(SRAMIN,sizeof(FILINFO));
   	if(fddir==NULL||finfo==NULL)res=100;
	if(res==0)
	{ 
 		pathname=mymalloc(SRAMIN,MAX_PATHNAME_DEPTH);	    
 		if(pathname==NULL)res=101;	   
 		if(res==0)
		{
			pathname[0]=0;	    
			strcat((char*)pathname,(const char*)fdname); 
		    res=f_opendir(fddir,(const TCHAR*)fdname); 		
		    if(res==0)//��Ŀ¼�ɹ� 
			{														   
				while(res==0)//��ʼ�����ļ�������Ķ���
				{
			        res=f_readdir(fddir,finfo);						
			        if(res!=FR_OK||finfo->fname[0]==0)break;		
			        if(finfo->fname[0]=='.')continue;     			
					if(finfo->fattrib&0X10)
					{
 						pathlen=strlen((const char*)pathname);		
						strcat((char*)pathname,(const char*)"/");	
						strcat((char*)pathname,(const char*)finfo->fname);	
 						//printf("\r\nsub folder:%s\r\n",pathname);	
						fdsize+=fatfs_fdsize(pathname);				
						pathname[pathlen]=0;						
					}else fdsize+=finfo->fsize;						
						
				} 
		    }	  
  			myfree(SRAMIN,pathname);	     
		}
 	}
	myfree(SRAMIN,fddir);    
	myfree(SRAMIN,finfo);
	if(res)return 0;
	else return fdsize;
}	  

u8 fatfs_fdcopy(u8(*fcpymsg)(u8*pname,u8 pct,u8 mode),u8 *psrc,u8 *pdst,u32 *totsize,u32 *cpdsize,u8 fwmode)
{
#define MAX_PATHNAME_DEPTH	512+1	
	u8 res=0;	  
    DIR *srcdir=0;	
	DIR *dstdir=0;	
	FILINFO *finfo=0;	
	u8 *fn=0;   		
	u8 * dstpathname=0;	
	u8 * srcpathname=0;
	
 	u16 dstpathlen=0;
 	u16 srcpathlen=0;	

  
	srcdir=(DIR*)mymalloc(SRAMIN,sizeof(DIR));
 	dstdir=(DIR*)mymalloc(SRAMIN,sizeof(DIR));
	finfo=(FILINFO*)mymalloc(SRAMIN,sizeof(FILINFO));

   	if(srcdir==NULL||dstdir==NULL||finfo==NULL)res=100;
	if(res==0)
	{ 
 		dstpathname=mymalloc(SRAMIN,MAX_PATHNAME_DEPTH);
		srcpathname=mymalloc(SRAMIN,MAX_PATHNAME_DEPTH);
 		if(dstpathname==NULL||srcpathname==NULL)res=101;	   
 		if(res==0)
		{
			dstpathname[0]=0;
			srcpathname[0]=0;
			strcat((char*)srcpathname,(const char*)psrc); 	
			strcat((char*)dstpathname,(const char*)pdst); 
		    res=f_opendir(srcdir,(const TCHAR*)psrc); 		
		    if(res==0)
			{
  				strcat((char*)dstpathname,(const char*)"/");
 				fn=fatfs_get_src_dname(psrc);
				if(fn==0)
				{
					dstpathlen=strlen((const char*)dstpathname);
					dstpathname[dstpathlen]=psrc[0];	
					dstpathname[dstpathlen+1]=0;		
				}else strcat((char*)dstpathname,(const char*)fn);
 				fcpymsg(fn,0,0X04);
				res=f_mkdir((const TCHAR*)dstpathname);
				if(res==FR_EXIST)res=0;
				while(res==0)
				{
			        res=f_readdir(srcdir,finfo);				
			        if(res!=FR_OK||finfo->fname[0]==0)break;	
			        if(finfo->fname[0]=='.')continue;     		
					fn=(u8*)finfo->fname; 							
					dstpathlen=strlen((const char*)dstpathname);	
					srcpathlen=strlen((const char*)srcpathname);	

					strcat((char*)srcpathname,(const char*)"/");
 					if(finfo->fattrib&0X10)
					{
						strcat((char*)srcpathname,(const char*)fn);		
						res=fatfs_fdcopy(fcpymsg,srcpathname,dstpathname,totsize,cpdsize,fwmode);	
					}else //��Ŀ¼
					{
						strcat((char*)dstpathname,(const char*)"/");
						strcat((char*)dstpathname,(const char*)fn);
						strcat((char*)srcpathname,(const char*)fn);	
 						fcpymsg(fn,0,0X01);
						res=fatfs_copy(fcpymsg,srcpathname,dstpathname,*totsize,*cpdsize,fwmode);
						*cpdsize+=finfo->fsize;
					}
					srcpathname[srcpathlen]=0;
					dstpathname[dstpathlen]=0;    
				} 
		    }	  
  			myfree(SRAMIN,dstpathname);
 			myfree(SRAMIN,srcpathname); 
		}
 	}
	myfree(SRAMIN,srcdir);
	myfree(SRAMIN,dstdir);
	myfree(SRAMIN,finfo);
    return res;	  
}

//�õ�path·����,Ŀ���ļ����ܸ���
//path:·��
//type:���ͣ�ͼƬ/�ı�/MP3�� TYPE_PICTURE��TYPE_MUSIC��TYPE_TEXT
//����ֵ:����Ч�ļ���
u16 fatfs_get_filetype_tnum(u8 *path,u8 type)
{	  
	u8 res;
	u16 rval=0;
 	DIR tdir;	 		
	FILINFO *tfileinfo;  			     
	tfileinfo=(FILINFO*)mymalloc(SRAMIN,sizeof(FILINFO));
    res=f_opendir(&tdir,(const TCHAR*)path); 	
	if(res==FR_OK&&tfileinfo)
	{
		while(1)
		{
	        res=f_readdir(&tdir,tfileinfo);       			 
	        if(res!=FR_OK||tfileinfo->fname[0]==0)break; 		 
			res=f_typetell((u8*)tfileinfo->fname);
			if((res&0XF0)==TYPE_BIN)
			{
				rval++;//��Ч�ļ�������1
			}
			else if((res&0XF0)==TYPE_LRC)
			{
				rval++;//��Ч�ļ�������1
			}
			else if((res&0XF0)==TYPE_GAME)
			{
				rval++;//��Ч�ļ�������1
			}
			else if((res&0XF0)==TYPE_TEXT)
			{
				rval++;//��Ч�ļ�������1
			}
			else if((res&0XF0)==TYPE_MUSIC)
			{
				rval++;//��Ч�ļ�������1
			}
			else if((res&0XF0)==TYPE_PICTURE)
			{
				rval++;
			}
		}  
	}  
	myfree(SRAMIN,tfileinfo);
	return rval;
}
