#include "iic.h"
#include "system.h"
#include<system.h>
void IIC_Init(void){
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB|RCC_APB2Periph_GPIOF,ENABLE);
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_1;
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOF,&GPIO_InitStructure);
	
}
void SDA_OUT(void){
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOF,&GPIO_InitStructure);
}
void SDA_IN(void){
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IPU;
	GPIO_Init(GPIOF,&GPIO_InitStructure);
}
void IIC_Start(void){
	SDA_OUT();
	IIC_SDA=1;
	IIC_SCL=1;
	delay_us(30);
	IIC_SDA=0;
	delay_us(5);
	IIC_SCL=0;
}
void IIC_Stop(void){
	SDA_OUT();
	IIC_SCL=0;
	delay_us(30);
	IIC_SDA=0;
	delay_us(5);
	IIC_SDA=1;
}
uint8_t IIC_Wait_Ack(void){
	uint8_t tempTime=0;
	SDA_IN();
	IIC_SDA=1;
	IIC_SCL=1;
	delay_us(5);
	while(READ_SDA){
		tempTime++;
		if(tempTime>250){
			IIC_Stop();
			return 1;
		}
		delay_us(5);
	}
	IIC_SCL=0;
	return 0;
}
void IIC_NACK(void){
	IIC_SCL=0;
	SDA_OUT();
	delay_us(5);
	IIC_SCL=1;
	delay_us(5);
	IIC_SCL=1;
	delay_us(5);
	IIC_SCL=0;
}
void IIC_Send_Byte(uint8_t txd){
	uint8_t t;
	SDA_OUT();
	IIC_SCL=0;
	delay_us(5);
	for(t=0;t<8;t++){
			IIC_SDA=(txd&0x80)>>7;
			txd<<=1;
			IIC_SCL=1;
			delay_us(5);
			IIC_SCL=0;
			delay_us(5);
	}
}

void IIC_Ack(void){
	IIC_SCL=0;
	SDA_OUT();
	delay_us(5);
	IIC_SDA=0;
	delay_us(5);
	IIC_SCL=1;
	delay_us(5);
	IIC_SCL=0;
}
void IIC_NAck(void)
{
	IIC_SCL=0;
	SDA_OUT();
	delay_us(5);
	IIC_SDA=1;
	delay_us(5);
	IIC_SCL=1;
	delay_us(5);
	IIC_SCL=0;
}	
u8 IIC_Read_Byte(u8 ack)
{
	u8 i,receive=0;
	SDA_IN();
    for(i=0;i<8;i++ )
	{
        IIC_SCL=0; 
        delay_us(5);
				IIC_SCL=1;
        receive<<=1;
        if(READ_SDA)receive++;   
				delay_us(5); 
    }					 
    if (!ack)
        IIC_NAck();
    else
        IIC_Ack(); 
    return receive;
}
