#ifndef _iic_h
#define _iic_h
#include "system.h"



#define IIC_SCL PBout(1)
#define IIC_SDA PFout(9)
#define READ_SDA PFin(9)

void IIC_Init(void);
void SDA_OUT(void);
void SDA_IN(void);
void IIC_Start(void);
void IIC_Stop(void);
uint8_t IIC_Wait_Ack(void);
void IIC_NACK(void);
void IIC_Send_Byte(uint8_t txd);
u8 IIC_Read_Byte(u8 ack);

#endif