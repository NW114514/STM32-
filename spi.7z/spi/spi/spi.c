#include<stm32f10x.h>
#include "system.h"
#include	"spi.h"
#define EN25X_WriteEnable		0x06 
#define EN25X_WriteDisable		0x04 
#define EN25X_ReadStatusReg		0x05 
#define EN25X_WriteStatusReg		0x01 
#define EN25X_ReadData			0x03 
#define EN25X_FastReadData		0x0B 
#define EN25X_FastReadDual		0x3B 
#define EN25X_PageProgram		0x02 
#define EN25X_BlockErase			0xD8 
#define EN25X_SectorErase		0x20 
#define EN25X_ChipErase			0xC7 
#define EN25X_PowerDown			0xB9 
#define EN25X_ReleasePowerDown	0xAB 
#define EN25X_DeviceID			0xAB 
#define EN25X_ManufactDeviceID	0x90 
#define EN25X_JedecDeviceID		0x9F 
#define	EN25QXX_CS 		PBout(12) 


void SPI2_Init(void){
	GPIO_InitTypeDef gpio;
	SPI_InitTypeDef spi;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI2,ENABLE);
	gpio.GPIO_Mode=GPIO_Mode_AF_PP;
	gpio.GPIO_Pin=GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;
	gpio.GPIO_Speed=GPIO_Speed_50MHz;
	
	spi.SPI_BaudRatePrescaler=SPI_BaudRatePrescaler_256;
	spi.SPI_CPHA=SPI_CPHA_2Edge;
	spi.SPI_CPOL=SPI_CPOL_High;
	spi.SPI_CRCPolynomial=7;
	spi.SPI_DataSize=SPI_DataSize_8b;
	spi.SPI_Direction=SPI_Direction_2Lines_FullDuplex;
	spi.SPI_FirstBit=SPI_FirstBit_MSB;
	spi.SPI_Mode=SPI_Mode_Master;
	spi.SPI_NSS=SPI_NSS_Soft;
	GPIO_Init(GPIOB,&gpio);
	SPI_Init(SPI2,&spi);
	SPI_Cmd(SPI2,ENABLE);
}
void SPI2_SetSpeed(uint8_t SPI){
	SPI2->CR1&=0xffc7;
	SPI2->CR1|=SPI;
	SPI_Cmd(SPI2,ENABLE);
}
uint8_t SPI2_ReadWriteByte(uint8_t data){
	while(SPI_I2S_GetFlagStatus(SPI2,SPI_I2S_FLAG_TXE)==RESET);
	SPI_I2S_SendData(SPI2,data);
	while(SPI_I2S_GetFlagStatus(SPI2,SPI_I2S_FLAG_RXNE)==RESET);
	return SPI_I2S_ReceiveData(SPI2);
}
void EN25QXX_Init(void){
	GPIO_InitTypeDef gpio;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB|RCC_APB2Periph_GPIOG,ENABLE);
	
	gpio.GPIO_Pin = GPIO_Pin_12;
	gpio.GPIO_Mode = GPIO_Mode_Out_PP;
	gpio.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &gpio);//��ʼ��
	GPIO_SetBits(GPIOB,GPIO_Pin_12);
	
	gpio.GPIO_Pin = GPIO_Pin_7;
	GPIO_Init(GPIOG, &gpio);//��ʼ��
	GPIO_SetBits(GPIOG,GPIO_Pin_12);
	
	SPI2_SetSpeed(SPI_BaudRatePrescaler_2);
}
uint8_t EN25QXX_ReadSR(void){
	uint8_t byte;
	EN25QXX_CS=0;
	SPI2_ReadWriteByte(EN25X_ReadStatusReg);
	byte=SPI2_ReadWriteByte(0xff);
	EN25QXX_CS=1;
	return byte;
}
void  EN25QXX_Write_SR(u8 sr){
	EN25QXX_CS=0;
	SPI2_ReadWriteByte(EN25X_WriteStatusReg);
	SPI2_ReadWriteByte(sr);
	EN25QXX_CS=1;
}
void EN25QXX_Write_Enable(void)   
{
	EN25QXX_CS=0;                             
   SPI2_ReadWriteByte(EN25X_WriteEnable);       
	EN25QXX_CS=1;                             	      
}
void EN25QXX_Write_Disable(void)   
{  
	EN25QXX_CS=0;                             
  SPI2_ReadWriteByte(EN25X_WriteDisable);       
	EN25QXX_CS=1;                               	      
} 
u16 EN25QXX_ReadID(void)
{
	u16 Temp = 0;	  
	EN25QXX_CS=0;				    
	SPI2_ReadWriteByte(0x90);  
	SPI2_ReadWriteByte(0x00); 	    
	SPI2_ReadWriteByte(0x00); 	    
	SPI2_ReadWriteByte(0x00); 	 			   
	Temp|=SPI2_ReadWriteByte(0xFF)<<8;  
	Temp|=SPI2_ReadWriteByte(0xFF);	 
	EN25QXX_CS=1;				    
	return Temp;
}  
void EN25QXX_Read(u8* pBuffer,u32 ReadAddr,u16 NumByteToRead)   
{ 
 	u16 i;   										    
	EN25QXX_CS=0;                       
    SPI2_ReadWriteByte(EN25X_ReadData);         
    SPI2_ReadWriteByte((u8)((ReadAddr)>>16));  
    SPI2_ReadWriteByte((u8)((ReadAddr)>>8));   
    SPI2_ReadWriteByte((u8)ReadAddr);   
    for(i=0;i<NumByteToRead;i++)
	{ 
        pBuffer[i]=SPI2_ReadWriteByte(0XFF);   
  }
	EN25QXX_CS=1;  				    	      
}
void EN25QXX_Write_Page(u8* pBuffer,u32 WriteAddr,u16 NumByteToWrite)
{
 	u16 i;  
    EN25QXX_Write_Enable();                  
	EN25QXX_CS=0;                              
    SPI2_ReadWriteByte(EN25X_PageProgram);        
    SPI2_ReadWriteByte((u8)((WriteAddr)>>16));
    SPI2_ReadWriteByte((u8)((WriteAddr)>>8));   
    SPI2_ReadWriteByte((u8)WriteAddr);   
    for(i=0;i<NumByteToWrite;i++)SPI2_ReadWriteByte(pBuffer[i]);
	EN25QXX_CS=1;                   
	EN25QXX_Wait_Busy();					  
}
void EN25QXX_Write_NoCheck(u8* pBuffer,u32 WriteAddr,u16 NumByteToWrite)   
{ 			 		 
	u16 pageremain;	   
	pageremain=256-WriteAddr%256;  	    
	if(NumByteToWrite<=pageremain)pageremain=NumByteToWrite;
	while(1)
	{	   
		EN25QXX_Write_Page(pBuffer,WriteAddr,pageremain);
		if(NumByteToWrite==pageremain)break;
	 	else //NumByteToWrite>pageremain
		{
			pBuffer+=pageremain;
			WriteAddr+=pageremain;	

			NumByteToWrite-=pageremain;			  
			if(NumByteToWrite>256)pageremain=256; 
			else pageremain=NumByteToWrite; 	
		}
	}	    
} 
uint8_t EN25QXX_BUFFER[4096];
void EN25QXX_Write(u8* pBuffer,u32 WriteAddr,u16 NumByteToWrite)   
{ 
	u32 secpos;
	u16 secoff;
	u16 secremain;	   
 	u16 i;    
	u8 * EN25QXX_BUF;	  
   	EN25QXX_BUF=EN25QXX_BUFFER;	     
 	secpos=WriteAddr/4096;
	secoff=WriteAddr%4096;
	secremain=4096-secoff;  
 	//printf("ad:%X,nb:%X\r\n",WriteAddr,NumByteToWrite);
 	if(NumByteToWrite<=secremain)secremain=NumByteToWrite;
	while(1) 
	{	
		EN25QXX_Read(EN25QXX_BUF,secpos*4096,4096);
		for(i=0;i<secremain;i++)
		{
			if(EN25QXX_BUF[secoff+i]!=0XFF)break;  
		}
		if(i<secremain)
		{
			EN25QXX_Erase_Sector(secpos);
			for(i=0;i<secremain;i++)	   
			{
				EN25QXX_BUF[i+secoff]=pBuffer[i];	  
			}
			EN25QXX_Write_NoCheck(EN25QXX_BUF,secpos*4096,4096);

		}else EN25QXX_Write_NoCheck(pBuffer,WriteAddr,secremain);	   
		if(NumByteToWrite==secremain)break;
		else
		{
			secpos++;
			secoff=0; 	 

		   	pBuffer+=secremain;  
			WriteAddr+=secremain;	   
		   	NumByteToWrite-=secremain;			
			if(NumByteToWrite>4096)secremain=4096;	
			else secremain=NumByteToWrite;			
		}	 
	}	 
}
void EN25QXX_Erase_Chip(void)   
{                                   
    EN25QXX_Write_Enable();                
    EN25QXX_Wait_Busy();   
  	EN25QXX_CS=0;                          
    SPI2_ReadWriteByte(EN25X_ChipErase);       
		EN25QXX_CS=1;                             	      
		EN25QXX_Wait_Busy();   				  
}
void EN25QXX_Erase_Sector(u32 Dst_Addr)   
{  
    
		Dst_Addr*=4096;
    EN25QXX_Write_Enable();
    EN25QXX_Wait_Busy();   
  	EN25QXX_CS=0;
    SPI2_ReadWriteByte(EN25X_SectorErase);     
    SPI2_ReadWriteByte((u8)((Dst_Addr)>>16));    
    SPI2_ReadWriteByte((u8)((Dst_Addr)>>8));   
    SPI2_ReadWriteByte((u8)Dst_Addr);  
		EN25QXX_CS=1;                             	      
    EN25QXX_Wait_Busy();   				  
}
void EN25QXX_Wait_Busy(void)   
{   
	while((EN25QXX_ReadSR()&0x01)==0x01);  
}
void EN25QXX_PowerDown(void)   
{ 
  	EN25QXX_CS=0;                            
    SPI2_ReadWriteByte(EN25X_PowerDown);       
		EN25QXX_CS=1;                              	      
                                  
}  