#ifndef _spi_H
#define _spi_H
#include<stm32f10x.h>
void EN25QXX_Init(void);
u16  EN25QXX_ReadID(void);  	    		//��ȡFLASH ID
u8	 EN25QXX_ReadSR(void);        		//��ȡ״̬�Ĵ��� 
void EN25QXX_Write_SR(u8 sr);  			//д״̬�Ĵ���
void EN25QXX_Write_Enable(void);  		//дʹ�� 
void EN25QXX_Write_Disable(void);		//д����
void EN25QXX_Write_NoCheck(u8* pBuffer,u32 WriteAddr,u16 NumByteToWrite);
void EN25QXX_Read(u8* pBuffer,u32 ReadAddr,u16 NumByteToRead);   //��ȡflash
void EN25QXX_Write(u8* pBuffer,u32 WriteAddr,u16 NumByteToWrite);//д��flash
void EN25QXX_Erase_Chip(void);    	  	//��Ƭ����
void EN25QXX_Erase_Sector(u32 Dst_Addr);	//��������
void EN25QXX_Wait_Busy(void);   
void EN25QXX_PowerDown(void);   
#endif