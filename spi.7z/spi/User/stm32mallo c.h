typedef unsigned int size_t;
typedef struct Block {size_t size;struct Block *s;} Block;
extern  Block* free_list;
#define NULL (void *)0
void initmalloc(void);
void* mymalloc(size_t size);
void myfree(void *ptr);
