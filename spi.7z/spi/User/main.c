#include "stm32f10x.h"
#include<tft.h>
#include<stdio.h>
#include<spi.h>
#include<fputc_fpetc.h>
#include<ff.h>
#include<oip.h>
#include<string.h>
#include<stdarg.h>
#include<tp.h>
#include<draw.h>
#include<ret.h>
#include<clock.h>
#include<time.h>
#include<led.h>
#include<open.h>
#include<dir.h>
#include<adc.h>
#include<math.h>
#include<sd_sdio.h>
#include<stm32mallo c.h>
#include<SARM.H>
#include<franc.h>
#include<vo.h>
#include<og.h>
#define M_PI 3.14159265358979323846
//res=f_mkfs("1:",1,4096);666!f_mkfs!
	//BYTE work[512];
FATFS fs;
FIL fp;
FRESULT res;
UINT bw;
FIL p;
DIR dir;
FILINFO fno;
uint8_t buff[128]={0};
uint32_t _time=1747291803;
uint32_t pwm=30;
uint32_t _time_=100;

uint16_t ADValue=0;
uint32_t adc=0;
uint32_t t=0;
DMA_InitTypeDef DMA_InitStructure;

uint32_t IC1Value=0;
uint32_t IC2Value=0;
float Voltage;
typedef struct TEXT{
	uint8_t *path;
	uint16_t	x1;
	uint16_t  y1;
	uint16_t  x2;
	uint16_t 	y2;
	uint8_t num;
}TEXT;
TEXT stm32_text[4];
TEXT _text(uint8_t *path,uint16_t x1,uint16_t y1,uint16_t x2,uint16_t y2,uint8_t num){
	TEXT _text;
	_text.path=path;
	_text.x1=x1;
	_text.y1=y1;
	_text.x2=x2;
	_text.y2=y2;
	_text.num=num;
	return _text;
}

double degress(double degress){
	return (double)degress*(M_PI/180.0);
}
void DMA_init(void){
		 
    
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
		DMA_DeInit(DMA1_Channel1);
    DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)&TFTLCD->LCD_DATA;
    DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)0;
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;
    DMA_InitStructure.DMA_BufferSize = 1;
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
    DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
    DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
    DMA_InitStructure.DMA_Priority = DMA_Priority_High;
    DMA_InitStructure.DMA_M2M = DMA_M2M_Enable;
    DMA_Init(DMA1_Channel1, &DMA_InitStructure);
    DMA_Cmd(DMA1_Channel1,ENABLE);
		DMA_DeInit(DMA1_Channel1);

}
void my_Clear(uint16_t start_x,uint16_t start_y,uint16_t stop_x,uint16_t stop_y,u16 color)
{
    DMA_init();
    DMA_DeInit(DMA1_Channel1);
    DMA_Cmd(DMA1_Channel1,DISABLE);
    DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)&(TFTLCD->LCD_DATA);
    DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)&color;
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;
    DMA_InitStructure.DMA_BufferSize = (uint32_t)(stop_x-start_x)*(stop_y-start_y);
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Disable;
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
    DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
    DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
    DMA_InitStructure.DMA_Priority = DMA_Priority_High;
    DMA_InitStructure.DMA_M2M = DMA_M2M_Enable ;
    DMA_Init(DMA1_Channel1, &DMA_InitStructure);
    LCD_Set_Window(start_x, start_y, stop_x-1, stop_y-1);
    DMA_Cmd(DMA1_Channel1,ENABLE);
    while(DMA_GetFlagStatus(DMA1_FLAG_TC1)==RESET);
    DMA_ClearFlag(DMA1_FLAG_TC1);
		
}
void PWM_Init(void){
	TIM_TimeBaseInitTypeDef tim3;
	TIM_OCInitTypeDef timoc;
	GPIO_InitTypeDef gpio;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE);

	
	gpio.GPIO_Mode=GPIO_Mode_AF_PP;
	gpio.GPIO_Pin=GPIO_Pin_5;
	gpio.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&gpio);
	
	GPIO_PinRemapConfig(GPIO_PartialRemap_TIM3,ENABLE);
	
	tim3.TIM_Period=710;
	tim3.TIM_Prescaler=0;
	tim3.TIM_CounterMode=TIM_CounterMode_Up;
	tim3.TIM_ClockDivision=TIM_CKD_DIV1;
	TIM_TimeBaseInit(TIM4,&tim3);

	timoc.TIM_OCMode=TIM_OCMode_PWM1;
	timoc.TIM_OCPolarity=TIM_OCPolarity_Low;
	timoc.TIM_OutputState=TIM_OutputState_Enable;
	TIM_OC2Init(TIM3,&timoc);
	TIM_OC2PreloadConfig(TIM3,TIM_OCPreload_Enable);
	TIM_ARRPreloadConfig(TIM3,ENABLE);
	
	TIM_Cmd(TIM3,ENABLE);
	TIM_SetCompare2(TIM3,400);
}

void TIM1_Init(void){
	TIM_TimeBaseInitTypeDef tim1;
	GPIO_InitTypeDef gpio;
	TIM_ICInitTypeDef timic;
	NVIC_InitTypeDef nvic;
	
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	
	nvic.NVIC_IRQChannel = TIM1_CC_IRQn;          
	nvic.NVIC_IRQChannelPreemptionPriority = 2;   
	nvic.NVIC_IRQChannelSubPriority = 0;      
	nvic.NVIC_IRQChannelCmd = ENABLE;  
	NVIC_Init(&nvic);
	
	gpio.GPIO_Pin=GPIO_Pin_8;
	gpio.GPIO_Mode=GPIO_Mode_IN_FLOATING;
	gpio.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&gpio);
	
	tim1.TIM_Period=0xffff;
	tim1.TIM_Prescaler=72-1;
	tim1.TIM_ClockDivision=TIM_CKD_DIV1;
	tim1.TIM_CounterMode=TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM1,&tim1);
	
	timic.TIM_Channel=TIM_Channel_1;
	timic.TIM_ICPolarity=TIM_ICPolarity_Rising;
	timic.TIM_ICPrescaler=TIM_ICPSC_DIV1;
	timic.TIM_ICSelection=TIM_ICSelection_DirectTI;
	timic.TIM_ICFilter=0x00;
	TIM_PWMIConfig(TIM1,&timic);
	TIM_ITConfig(TIM1,TIM_IT_CC1,ENABLE);
	TIM_SelectInputTrigger(TIM1,TIM_TS_TI1FP1);
	TIM_SelectSlaveMode(TIM1,TIM_SlaveMode_Reset);
	TIM_SelectMasterSlaveMode(TIM1,TIM_MasterSlaveMode_Enable);
	
	
	
	

	TIM_Cmd(TIM1,ENABLE);
	TIM_GenerateEvent(TIM1,TIM_IT_CC1);
}
void ADCx_Init(void){
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_ADC1,ENABLE);
	ADC_TempSensorVrefintCmd(ENABLE);
	GPIO_InitTypeDef gpio;
	ADC_InitTypeDef adc;
	NVIC_InitTypeDef nvic;
	
	gpio.GPIO_Mode=GPIO_Mode_AIN;
	gpio.GPIO_Pin=GPIO_Pin_3;
	
	
	RCC_ADCCLKConfig(RCC_PCLK2_Div6);
	
	adc.ADC_Mode=ADC_Mode_Independent;
	adc.ADC_ScanConvMode=DISABLE;
	adc.ADC_ContinuousConvMode=DISABLE;
	adc.ADC_ExternalTrigConv=ADC_ExternalTrigConv_None;
	adc.ADC_DataAlign=ADC_DataAlign_Right;
	adc.ADC_NbrOfChannel=1;
	
	
	
	GPIO_Init(GPIOA,&gpio);
	ADC_Init(ADC1,&adc);
	
	
	ADC_Cmd(ADC1,ENABLE);
	
	
	
	
	
	ADC_ResetCalibration(ADC1);
	while(ADC_GetResetCalibrationStatus(ADC1)==SET);
	ADC_StartCalibration(ADC1);
	
	while(ADC_GetCalibrationStatus(ADC1)==SET);	
	
	ADC_SoftwareStartConvCmd(ADC1,ENABLE);
}
uint16_t AD_GetValue(void){
	ADC_SoftwareStartConvCmd(ADC1,ENABLE);
	while(ADC_GetFlagStatus(ADC1,ADC_FLAG_EOC)==RESET);
	return ADC_GetConversionValue(ADC1);
	
}
void PWM(uint32_t _pwm){
	_time_=_pwm;
}	
void RTC_SetAlarmTime(uint32_t time)
{
	PWR_BackupAccessCmd(ENABLE);
	RTC_SetAlarm(time);
	RTC_WaitForLastTask();
}
void RTC_Init()                                           
{
	NVIC_InitTypeDef NVIC_InitStructure;   
	EXTI_InitTypeDef EXTI_Instructure;  
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_APB1Periph_BKP,ENABLE); 
	PWR_BackupAccessCmd(ENABLE);                         
	RCC_LSICmd(ENABLE);                          
	while(RCC_GetFlagStatus(RCC_FLAG_LSIRDY) == RESET);   
	
	RCC_RTCCLKConfig(RCC_RTCCLKSource_LSI);                 
	
	RCC_RTCCLKCmd(ENABLE);                                 
	
	RTC_WaitForSynchro();                                
	
	RTC_WaitForLastTask();                                 
	
	RTC_ITConfig(RTC_IT_SEC,ENABLE);                        
	RTC_ITConfig(RTC_IT_ALR,ENABLE);                        
	
	RTC_WaitForLastTask();                               
	RTC_SetPrescaler(40000-1);                            
	
	RTC_WaitForLastTask();                                 
	
                 
	NVIC_InitStructure.NVIC_IRQChannel = RTC_IRQn;          
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;   
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;      
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;        
	
	NVIC_Init(&NVIC_InitStructure);                         
	
	NVIC_InitStructure.NVIC_IRQChannel = RTCAlarm_IRQn;     
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;  
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;     
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;        
	
	NVIC_Init(&NVIC_InitStructure);                    
	EXTI_Instructure.EXTI_Line = EXTI_Line17;               
	EXTI_Instructure.EXTI_Mode = EXTI_Mode_Interrupt;      
	EXTI_Instructure.EXTI_Trigger = EXTI_Trigger_Rising;    
	EXTI_Instructure.EXTI_LineCmd = ENABLE;                 
	EXTI_Init(&EXTI_Instructure);                           
}
void RTC_SetTime(uint32_t time)    
{
	RTC_SetCounter(time);       
	RTC_WaitForLastTask();      
}
void RTC_GetTime(uint8_t *buff)                  
{
	struct tm *time;               
	time_t time_temp = RTC_GetCounter();   
	time = localtime(&time_temp);   
	//sprintf((char *)buff,"%d%d%d%d:%d:%d\n",time->tm_year,time->tm_mon,time->tm_mday,time->tm_hour,time->tm_min,time->tm_sec);
	sprintf((char *)buff,"%s",asctime(time));
}
void LCD_printf(uint16_t x,uint16_t y,unsigned char *ptr){
	LCD_ShowString(x,y,tftlcd_data.wigth,tftlcd_data.height,12,ptr);
}
void scanf_text(uint8_t *path,uint8_t *buff){
	DIR _dir;
	FILINFO fno;
	if(f_opendir(&dir,(const TCHAR *)path)!=FR_OK)return;
	while(f_readdir(&dir,&fno)==FR_OK){
		if(!fno.fname[0])break;
		if(fno.fattrib&AM_ARC){
			sprintf((char *)buff,"%s/%s",path,fno.fname);
		}
	}
}
void scanf_dir(uint8_t *path,uint8_t *buff){
	DIR _dir;
	FILINFO fno;
	if(f_opendir(&dir,(const TCHAR *)path)==FR_OK){
		while(f_readdir(&dir,&fno)==FR_OK){
			if(!fno.fname[0])break;
			if(fno.fattrib&AM_DIR){
				sprintf((char *)buff,"%s/%s",path,fno.fname);
			}
		}
	}
}
void _printf_(uint16_t x, uint16_t y, const char *fmt, ...) {
    char buff[1024];  
    va_list args;
    
    va_start(args, fmt);
    vsnprintf(buff, sizeof(buff), fmt, args);
    va_end(args);
		LCD_printf(x,y,buff);
}
void LED_Init(void){
	GPIO_InitTypeDef gpio;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB|RCC_APB2Periph_GPIOE,ENABLE);
	gpio.GPIO_Mode=GPIO_Mode_Out_PP;
	gpio.GPIO_Pin=GPIO_Pin_5;
	gpio.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&gpio);
	GPIO_Init(GPIOE,&gpio);
	
}

//SARM
void remove_crlf(char *str) {
    char *p = str;
    while(*p) {
        if(*p == '\r' || *p == '\n') {
            memmove(p, p+1, strlen(p));
        } else {
            p++;
        }
    }
}
void remove_last_char_lib(char *str) {
    size_t len = strlen(str);
    if(len > 0) {
        memmove(&str[len-1], &str[len], 1);  
    }
}
#define BEEP PBout(8)
uint16_t C[]={
		3822/2, 3405/2, 3034/2, 2863/2, 2551/2, 2273/2, 2025/2,  
    
    1911/2, 1703/2, 1517/2, 1432/2, 1276/2, 1136/2, 1012/2, 
    
    956/2,  880,851/2,  758/2,  716/2,  638/2,  568/2,  506/2   
    
};

//uint16_t D[]={
//		 3822/2, 3405/2, 3034/2, 2863/2, 2551/2, 2273/2, 2025/2,  
//    
//    293, 329, 349, 391, 440, 1136/2, 1012/2, 
//    
//    956/2,  851/2,  758/2,  716/2,  638/2,  568/2,  506/2   
//};
uint16_t *music=C;
const uint16_t D[] = {
    146, 164, 185, 196, 220,
    246, 277, 293, 329, 369,
    392, 440, 493, 554, 587,
    659, 739, 783
};
uint16_t i=0;
void BEEP_Init(void){
	GPIO_InitTypeDef gpio;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6, ENABLE);
	TIM_TimeBaseInitTypeDef tim6;
	NVIC_InitTypeDef nvic;
	
	gpio.GPIO_Mode=GPIO_Mode_Out_PP;
	gpio.GPIO_Pin=GPIO_Pin_8;
	gpio.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&gpio);
	
	nvic.NVIC_IRQChannel = TIM6_IRQn;     	
	nvic.NVIC_IRQChannelPreemptionPriority = 2;   
	nvic.NVIC_IRQChannelSubPriority = 0;      
	nvic.NVIC_IRQChannelCmd = ENABLE;  
	NVIC_Init(&nvic);
	
	tim6.TIM_Period=955;
	tim6.TIM_Prescaler=72-1;
	tim6.TIM_ClockDivision=TIM_CKD_DIV1;
	tim6.TIM_CounterMode=TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM6,&tim6);
	TIM_ITConfig(TIM6,TIM_IT_Update,ENABLE);
	TIM_Cmd(TIM6,DISABLE);
	TIM_ClearITPendingBit(TIM6,TIM_IT_Update);
}
void BEEP_DAC(void){
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_DAC,ENABLE);
	GPIO_InitTypeDef gpio;
	DAC_InitTypeDef dac;
	
	gpio.GPIO_Mode=GPIO_Mode_AIN;
	gpio.GPIO_Pin=GPIO_Pin_4;
	gpio.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&gpio);
	
	dac.DAC_Trigger=DAC_Trigger_None;
	dac.DAC_WaveGeneration=DAC_WaveGeneration_None;
	dac.DAC_LFSRUnmask_TriangleAmplitude=DAC_LFSRUnmask_Bit0;
	dac.DAC_OutputBuffer=DAC_OutputBuffer_Enable;
	DAC_Init(DAC_Channel_1,&dac);
	DAC_SetChannel1Data(DAC_Align_12b_R,0);
	DAC_Cmd(DAC_Channel_1,ENABLE);
	
	DAC_SetChannel1Data(DAC_Align_12b_R,4096);

}
void SystemClockConfig(void) {
    RCC_HSICmd(ENABLE);
    while (RCC_GetFlagStatus(RCC_FLAG_HSIRDY) == RESET); 

    RCC_HSEConfig(RCC_HSE_OFF);
    RCC_PLLCmd(DISABLE);        

    RCC_PLLConfig(RCC_PLLSource_HSI_Div2, RCC_PLLMul_16); 
    RCC_PLLCmd(ENABLE);
    while (RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET); 

    RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);      
    while (RCC_GetSYSCLKSource() != 0x08);           
    RCC_PCLK1Config(RCC_HCLK_Div2);
}
int main(void){
	
	SystemClockConfig();
	initmalloc();
	DMA_init();
	USARTI_init(115200);
	SysTick_Init(72);
	TFTLCD_Init();
	TP_Init();
	RTC_Init();
	LED_Init();
	LCD_Clear(0XFFFF);
	SD_Init();
	ADCx_Init();
	TIM1_Init();
	FSMC_Init();
	
	uint8_t *free=(uint8_t *)mymalloc(1);
	myfree(free);
	res=f_mount(&fs,"1:",1);
	res=f_open(&fp,"1:/1.txt",FA_OPEN_ALWAYS|FA_WRITE);
	res=f_write(&fp,"When Trump threatens Apple, iPhone rings! On May 23,",64,&bw);
	res=f_close(&fp);
	
	res=f_open(&fp,"1:/dos/dos.txt",FA_OPEN_ALWAYS|FA_WRITE);
	res=f_write(&fp,(const uint32_t *)&(_time),sizeof(uint32_t ),&bw);
	res=f_close(&fp);
	
	res=f_open(&fp,"1:/dos/dos.txt",FA_OPEN_ALWAYS|FA_READ);
	res=f_read(&fp,&_time,sizeof(uint32_t),&bw);
	res=f_close(&fp);
	
	res=f_open(&fp,"1:/dos/dos.txt",FA_OPEN_ALWAYS|FA_WRITE);
	res=f_write(&fp,(const uint32_t *)&(_time),sizeof(uint32_t ),&bw);
	res=f_close(&fp);
	
	RTC_SetTime(_time);
	FRONT_COLOR=BLACK;

	
	

	while(1){
		PBout(5)=1;
		PEout(5)=1;
		FRONT_COLOR=BLACK;
		LCD_ShowString(0,0,tftlcd_data.wigth,tftlcd_data.height,24,"--SZH--2025/6/7");
		LCD_ShowString(0,26,tftlcd_data.wigth,tftlcd_data.height,24,"@GPLV3.0");
		LCD_ShowString(0,48,tftlcd_data.wigth,tftlcd_data.height,24,"OS2.0V");
		LCD_ShowString(0,69,tftlcd_data.wigth,tftlcd_data.height,24,"NEXT-OSV3?,WILL 2025/7-8/31?");
		LCD_ShowString(0,89,tftlcd_data.wigth,tftlcd_data.height,24,"------- C~(TAT)~STM32 (-O-)?");
		if(TP_Scanf(0)){
			if(tp_dev.x[0]>=10&&tp_dev.y[0]>200&&tp_dev.x[0]<=10+89+10&&tp_dev.y[0]<=200+89+10){
					uint8_t i=1;
					LCD_Clear(0Xffff);
					FRONT_COLOR=BLACK;
					LCD_Fill(60,660,260,690,FRONT_COLOR);
					FRONT_COLOR=RED ;
					LCD_Fill(160,660,360,690,FRONT_COLOR);
					FRONT_COLOR=BRED;
					LCD_Fill(260,660,560,690,FRONT_COLOR);
					FRONT_COLOR=GRED;
					LCD_Fill(360,660,690,690,FRONT_COLOR);
			
				while(1){
						TP_Scanf(0);
						LCD_Fill(0,0,700,20,LBBLUE);
						LCD_Fill(0,10,700,20,DARKBLUE);
						LCD_ShowString(500,0,tftlcd_data.wigth,tftlcd_data.height,24,"DRAW");
					
						LCD_Fill(400,200,460,249,LBBLUE);
						LCD_Fill(400,230,460,250,DARKBLUE);
					
						LCD_Fill(tp_dev.x[0],tp_dev.y[0],tp_dev.x[0]+i,tp_dev.y[0]+i,FRONT_COLOR);

						if(tp_dev.x[0]>=390&&tp_dev.y[0]>198&&tp_dev.x[0]<=454&&tp_dev.y[0]<=254){
							i++;
							if(i>=36){
								i=0;
							}
						}
						if(tp_dev.x[0]>=60&&tp_dev.y[0]>650&&tp_dev.x[0]<=260&&tp_dev.y[0]<=690){
							FRONT_COLOR=BLACK;
						}
						if(tp_dev.x[0]>=160&&tp_dev.y[0]>650&&tp_dev.x[0]<360&&tp_dev.y[0]<=690){
							FRONT_COLOR=RED ;
						}
						if(tp_dev.x[0]>=260&&tp_dev.y[0]>650&&tp_dev.x[0]<=560&&tp_dev.y[0]<=690){
							FRONT_COLOR=BRED;
						}
						if(tp_dev.x[0]>=360&&tp_dev.y[0]>550&&tp_dev.x[0]<=690&&tp_dev.y[0]<=690){
							FRONT_COLOR=GRED;
						}
						if(tp_dev.x[0]>=0&&tp_dev.y[0]>563&&tp_dev.x[0]<=59&&tp_dev.y[0]<=660){
							FRONT_COLOR=0xffff;
						}
						LCD_ShowPicture(400,590,30,24,(u8*)gImage_ret);
						LCD_ShowPicture(0,590,20,20,(u8*)gImage_open);
						if(tp_dev.x[0]>=360&&tp_dev.y[0]>550&&tp_dev.x[0]<=450&&tp_dev.y[0]<=690){
							LCD_Clear(0Xffff);
							break;
						}
					}
			}
			if(tp_dev.x[0]>=150&&tp_dev.y[0]>200&&tp_dev.x[0]<=150+87&&tp_dev.y[0]<=200+77){
				LCD_Clear(0xffff);
				uint8_t ftime=0;
				struct tm *time; 
				while(1){
						LCD_Clear(0x0000);	
						LCD_Fill(0,0,700,20,LBBLUE);
						LCD_Fill(0,10,700,20,DARKBLUE);
						
						FRONT_COLOR=DARKBLUE;	
									
						LCD_Fill(0,0,700,20,LBBLUE);
						LCD_Fill(0,10,700,20,DARKBLUE);
						FRONT_COLOR=DARKBLUE;	
						LCD_DrawLine(tftlcd_data.wigth/2,tftlcd_data.height/2,tftlcd_data.wigth/2+(-200.0)*(double)cos(degress(90.0+(time->tm_sec)*6.0)),tftlcd_data.height/2+(-200.0)*sin(degress(90.0+(time->tm_sec)*6.0)));
						LCD_DrawLine(tftlcd_data.wigth/2,tftlcd_data.height/2,tftlcd_data.wigth/2+(-150.0)*(double)cos(degress(90.0+(time->tm_min)*6.0)),tftlcd_data.height/2+(-150.0)*sin(degress(90.0+(time->tm_min)*6.0)));
						LCD_DrawLine(tftlcd_data.wigth/2,tftlcd_data.height/2,tftlcd_data.wigth/2+(-75.0)*(double)cos(degress(90.0+(time->tm_hour)*30.0)+(time->tm_min)*0.5),tftlcd_data.height/2+(-75.0)*sin(degress(90.0+(time->tm_hour)*30.0+(time->tm_min)*0.5)));
											
						              

					



						LCD_Fill(0,0,700,20,LBBLUE);
						LCD_Fill(0,10,700,20,DARKBLUE);
						LCD_ShowString(tftlcd_data.wigth/2+(180.0)*(double)cos(degress(-90.0)),tftlcd_data.height/2+(180.0)*sin(degress(-90.0)),tftlcd_data.wigth,tftlcd_data.height,24,"12");
						LCD_ShowString(tftlcd_data.wigth/2+(180.0)*(double)cos(degress(-90.0+30.0)),tftlcd_data.height/2+(180.0)*sin(degress(-90.0+30.0)),tftlcd_data.wigth,tftlcd_data.height,24,"1");
						LCD_ShowString(tftlcd_data.wigth/2+(180.0)*(double)cos(degress(-90.0+60.0)),tftlcd_data.height/2+(180.0)*sin(degress(-90.0+60.0)),tftlcd_data.wigth,tftlcd_data.height,24,"2");
						LCD_ShowString(tftlcd_data.wigth/2+(180.0)*(double)cos(degress(7.0)),tftlcd_data.height/2+(180.0)*sin(degress(7.0)),tftlcd_data.wigth,tftlcd_data.height,24,"3");
						LCD_ShowString(tftlcd_data.wigth/2+(180.0)*(double)cos(degress(30.0)),tftlcd_data.height/2+(180.0)*sin(degress(30.0)),tftlcd_data.wigth,tftlcd_data.height,24,"4");
						LCD_ShowString(tftlcd_data.wigth/2+(180.0)*(double)cos(degress(60.0)),tftlcd_data.height/2+(180.0)*sin(degress(60.0)),tftlcd_data.wigth,tftlcd_data.height,24,"5");						
						LCD_ShowString(tftlcd_data.wigth/2+(180.0)*(double)cos(degress(93.0)),tftlcd_data.height/2+(180.0)*sin(degress(93.0)),tftlcd_data.wigth,tftlcd_data.height,24,"6");
						LCD_ShowString(tftlcd_data.wigth/2+(180.0)*(double)cos(degress(127.0)),tftlcd_data.height/2+(180.0)*sin(degress(127.0)),tftlcd_data.wigth,tftlcd_data.height,24,"7");
						LCD_ShowString(tftlcd_data.wigth/2+(180.0)*(double)cos(degress(157.0)),tftlcd_data.height/2+(180.0)*sin(degress(157.0)),tftlcd_data.wigth,tftlcd_data.height,24,"8");
						LCD_ShowString(tftlcd_data.wigth/2+(180.0)*(double)cos(degress(187.0)),tftlcd_data.height/2+(180.0)*sin(degress(187.0)),tftlcd_data.wigth,tftlcd_data.height,24,"9");
						LCD_ShowString(tftlcd_data.wigth/2+(180.0)*(double)cos(degress(217.0)),tftlcd_data.height/2+(180.0)*sin(degress(217.0)),tftlcd_data.wigth,tftlcd_data.height,24,"10");
						LCD_ShowString(tftlcd_data.wigth/2+(180.0)*(double)cos(degress(247.0)),tftlcd_data.height/2+(180.0)*sin(degress(247.0)),tftlcd_data.wigth,tftlcd_data.height,24,"11");
						LCD_ShowString(100,700,tftlcd_data.wigth,tftlcd_data.height,24,buff);
						
						LCD_ShowPicture(400,590,30,24,(u8*)gImage_ret);
						if(tp_dev.x[0]>=240&&tp_dev.y[0]>400&&tp_dev.x[0]<=490&&tp_dev.y[0]<=690){
							f_open(&fp,"1:/dos/dos.txt",FA_OPEN_ALWAYS|FA_WRITE);
							f_write(&fp,(const uint32_t *)&(_time),sizeof(uint32_t ),&bw);
							f_close(&fp);
							LCD_Clear(0Xffff);
							break;
						}

						
						FRONT_COLOR=RED;	
						LCD_Draw_Circle(tftlcd_data.wigth/2,tftlcd_data.height/2,1.0);
						LCD_Draw_Circle(tftlcd_data.wigth/2,tftlcd_data.height/2,2.0);
						LCD_Draw_Circle(tftlcd_data.wigth/2,tftlcd_data.height/2,3.0);
						LCD_Draw_Circle(tftlcd_data.wigth/2,tftlcd_data.height/2,4.0);
						LCD_Draw_Circle(tftlcd_data.wigth/2,tftlcd_data.height/2,5.0);
						LCD_Draw_Circle(tftlcd_data.wigth/2,tftlcd_data.height/2,6.0);
						LCD_Draw_Circle(tftlcd_data.wigth/2,tftlcd_data.height/2,7.0);
						LCD_Draw_Circle(tftlcd_data.wigth/2,tftlcd_data.height/2,8.0);
						LCD_Draw_Circle(tftlcd_data.wigth/2,tftlcd_data.height/2,9.0);
						FRONT_COLOR=DARKBLUE;	
						
						LCD_Draw_Circle(tftlcd_data.wigth/2,tftlcd_data.height/2,200.0);
						LCD_Draw_Circle(tftlcd_data.wigth/2,tftlcd_data.height/2,201.0);
						LCD_Draw_Circle(tftlcd_data.wigth/2,tftlcd_data.height/2,202.0);
						LCD_Draw_Circle(tftlcd_data.wigth/2,tftlcd_data.height/2,203.0);
						LCD_Draw_Circle(tftlcd_data.wigth/2,tftlcd_data.height/2,204.0);
						LCD_Draw_Circle(tftlcd_data.wigth/2,tftlcd_data.height/2,205.0);
						LCD_Draw_Circle(tftlcd_data.wigth/2,tftlcd_data.height/2,206.0);
						LCD_Draw_Circle(tftlcd_data.wigth/2,tftlcd_data.height/2,207.0);
						for(int i=208;i<251;i+=1){
							
							FRONT_COLOR=0X7D7C;
							LCD_Draw_Circle(tftlcd_data.wigth/2,tftlcd_data.height/2,i);
							LCD_Fill(0,0,700,20,LBBLUE);
							LCD_Fill(0,10,700,20,DARKBLUE);
						}
						LCD_Fill(0,0,700,20,LBBLUE);
						LCD_Fill(0,10,700,20,DARKBLUE);	
							

						
						FRONT_COLOR=DARKBLUE;	
						LCD_Draw_Circle(tftlcd_data.wigth/2,tftlcd_data.height/2,251.0);
						LCD_Draw_Circle(tftlcd_data.wigth/2,tftlcd_data.height/2,252.0);
						LCD_Draw_Circle(tftlcd_data.wigth/2,tftlcd_data.height/2,253.0);	
						LCD_Draw_Circle(tftlcd_data.wigth/2,tftlcd_data.height/2,254.0);
						LCD_Draw_Circle(tftlcd_data.wigth/2,tftlcd_data.height/2,255.0);
							
						FRONT_COLOR=DARKBLUE;	

						time_t time_temp = RTC_GetCounter();   //k*360+
						time = localtime(&time_temp);

						FRONT_COLOR=DARKBLUE;	
						
						f_open(&fp,"1:/dos/dos.txt",FA_OPEN_ALWAYS|FA_WRITE);
						f_write(&fp,(const uint32_t *)&(_time),sizeof(uint32_t ),&bw);
						f_close(&fp);
						f_open(&fp,"1:/dos/dos.txt",FA_OPEN_ALWAYS|FA_READ);
						f_read(&fp,&_time,sizeof(uint32_t),&bw);
						f_close(&fp);
						RTC_GetTime(buff);
						TP_Scanf(0);			


				}
			}

		}
		if(tp_dev.x[0]>=270&&tp_dev.y[0]>200&&tp_dev.x[0]<=250+87&&tp_dev.y[0]<=200+77){
				LCD_Clear(0X0000);
				uint8_t kmp=0;
				while(1){
							TP_Scanf(0);
							LCD_Fill(0,0,700,20,LBBLUE);
							LCD_Fill(0,10,700,20,DARKBLUE);
							FRONT_COLOR=0x0000;
							if(tp_dev.x[0]>=10&&tp_dev.y[0]>150&&tp_dev.x[0]<=150&&tp_dev.y[0]<=260){
								delay_ms(5);	
								if(tp_dev.x[0]>=10&&tp_dev.y[0]>150&&tp_dev.x[0]<=150&&tp_dev.y[0]<=260){
											PBout(5)=0;
											LCD_Draw_Circle(110,225,20);
											for(int i=11;i<19;i++){
													FRONT_COLOR=LIGHTBLUE;
													LCD_Draw_Circle(110,225,i);
											}
											FRONT_COLOR=0x0000;
											LCD_Draw_Circle(110,225,10);
											for(int i=1;i<9;i++){
													FRONT_COLOR=RED;
													LCD_Draw_Circle(110,225,i);
											}
								}
						}
							if(tp_dev.x[0]>=10&&tp_dev.y[0]>380&&tp_dev.x[0]<=150&&tp_dev.y[0]<=460){
								delay_ms(5);	
								if(tp_dev.x[0]>=10&&tp_dev.y[0]>380&&tp_dev.x[0]<=150&&tp_dev.y[0]<=460){

										PEout(5)=0;
									
										LCD_Draw_Circle(110,425,20);
										for(int i=11;i<19;i++){
												FRONT_COLOR=LIGHTBLUE;
												LCD_Draw_Circle(110,425,i);
										}
										FRONT_COLOR=0x0000;
										LCD_Draw_Circle(110,425,10);
										for(int i=1;i<9;i++){
												FRONT_COLOR=RED;
												LCD_Draw_Circle(110,425,i);
										}										
								}
							}
							
							if(tp_dev.x[0]>=240&&tp_dev.y[0]>500&&tp_dev.x[0]<=490&&tp_dev.y[0]<=690){
								LCD_Clear(0Xffff);
								
								break;
							}
							if(tp_dev.x[0]>=380&&tp_dev.y[0]>180&&tp_dev.x[0]<=400+60&&tp_dev.y[0]<=200+20){
								LCD_Fill(400,200,460,250,LBBLUE);
								LCD_Fill(400,230,460,250,DARKBLUE);
								LCD_ShowString(404,205,tftlcd_data.wigth,tftlcd_data.height,16,"OK..");
								delay_ms(1000);
								PWM_Init();
								TIM_Cmd(TIM3,ENABLE);
								PWM(300);
							}
							if(tp_dev.x[0]>=380&&tp_dev.y[0]>280&&tp_dev.x[0]<=400+60&&tp_dev.y[0]<=300+20){
									LCD_Fill(400,300,460,340,LBBLUE);
									LCD_Fill(400,330,460,350,DARKBLUE);								
									kmp+=5;
									TIM_SetCompare2(TIM3,kmp);
								if(kmp>499){
									kmp=0;
								}
								_printf_(404,305,"%d",kmp);
								delay_ms(1000);
							}
							if(tp_dev.x[0]>=380&&tp_dev.y[0]>480&&tp_dev.x[0]<=400+60&&tp_dev.y[0]<=500+20){
								LCD_Fill(400,200,460,240,LBBLUE);
								LCD_Fill(400,230,460,250,DARKBLUE);
								LCD_ShowString(404,205,tftlcd_data.wigth,tftlcd_data.height,16,"OK");
								TIM_Cmd(TIM3,DISABLE);
								delay_ms(1000);
							}
							PBout(5)=1;
							PEout(5)=1;
							LCD_Fill(400,300,460,340,LBBLUE);
							LCD_Fill(400,330,460,350,DARKBLUE);//+pwm
							LCD_DrawRectangle(398,329,461,351);
							LCD_ShowString(404,305,tftlcd_data.wigth,tftlcd_data.height,16,"PWM+");
							
							LCD_Fill(400,500,460,540,LBBLUE);
							LCD_Fill(400,530,460,550,DARKBLUE);							
							LCD_ShowString(404,505,tftlcd_data.wigth,tftlcd_data.height,16,"DIASBLE");							
							
							LCD_Fill(400,200,460,240,LBBLUE);
							LCD_Fill(400,230,460,250,DARKBLUE);
							LCD_ShowString(404,205,tftlcd_data.wigth,tftlcd_data.height,16,"ENABLE");
							LCD_DrawRectangle(398,229,461,251);
							
							FRONT_COLOR=GREEN;
							LCD_ShowString(20+2,215,tftlcd_data.wigth,tftlcd_data.height,24,"Led0");
							FRONT_COLOR=0x0000;
							LCD_Draw_Circle(110,225,20);
							for(int i=11;i<19;i++){
									FRONT_COLOR=LIGHTBLUE;
									LCD_Draw_Circle(110,225,i);
							}
							FRONT_COLOR=0x0000;
							LCD_Draw_Circle(110,225,10);
							for(int i=1;i<9;i++){
									FRONT_COLOR=GREEN;
									LCD_Draw_Circle(110,225,i);
							}
							
							FRONT_COLOR=GREEN;
							LCD_ShowString(20+2,415,tftlcd_data.wigth,tftlcd_data.height,24,"Led1");
							FRONT_COLOR=0x0000;
							LCD_Draw_Circle(110,425,20);
							for(int i=11;i<19;i++){
									FRONT_COLOR=LIGHTBLUE;
									LCD_Draw_Circle(110,425,i);
							}
							FRONT_COLOR=0x0000;
							LCD_Draw_Circle(110,425,10);
							for(int i=1;i<9;i++){
									FRONT_COLOR=GREEN;
									LCD_Draw_Circle(110,425,i);
							}
							FRONT_COLOR=0x0000;
					

							LCD_ShowPicture(400,590,30,24,(u8*)gImage_ret);
							
					}
		}
		if(tp_dev.x[0]>=10&&tp_dev.y[0]>390&&tp_dev.x[0]<=10+90&&tp_dev.y[0]<=400+90){
				LCD_Clear(0Xffff);
				res=f_mount(&fs,"0:",1);
				LCD_Clear(LIGHTBLUE);
				uint8_t *buf=(uint8_t*)mymalloc(sizeof(uint8_t)*32);//4*8
				while(1){
					TP_Scanf(0);
					
					LCD_Fill(0,0,700,20,LBBLUE);
					LCD_Fill(0,10,700,20,DARKBLUE);
					
					scanf_text((uint8_t *)"0:",(uint8_t *)(buf));
					
					LCD_Fill(10,60,40,90,BRRED);
					LCD_DrawRectangle(10,60,40,90);
					LCD_DrawLine(10,70,20,70);
					LCD_DrawLine(10,80,20,80);
					_printf_(10,95,"%s",buf);
					LCD_ShowPicture(400,590,30,24,(u8*)gImage_ret);
					
					
					if(tp_dev.x[0]>=240&&tp_dev.y[0]>500&&tp_dev.x[0]<=490&&tp_dev.y[0]<=690){
							LCD_Clear(0Xffff);
							res=f_mount(&fs,"0:",0);
							myfree(buf);
							break;
					}
					else	if(tp_dev.x[0]>=0&&tp_dev.y[0]>30&&tp_dev.x[0]<=100&&tp_dev.y[0]<=200){
							
							LCD_Clear(LIGHTBLUE);
							LCD_Fill(0,0,700,20,LBBLUE);
							LCD_Fill(0,10,700,20,DARKBLUE);
							LCD_ShowString(tftlcd_data.wigth/2-50,0,tftlcd_data.wigth,tftlcd_data.height,16,buf);
							uint8_t *text=(uint8_t *)mymalloc(sizeof (uint8_t)*64);
							uint16_t color;
							f_open(&fp,(TCHAR *)(buf),FA_OPEN_ALWAYS|FA_READ);
							f_gets((TCHAR *)text,64,&fp);
							f_close(&fp);
							while(1){
										
										TP_Scanf(0);
										LCD_DrawRectangle(tp_dev.x[0],tp_dev.y[0],tp_dev.x[0],tp_dev.y[0]+30);
										color=FRONT_COLOR;
										FRONT_COLOR=LIGHTBLUE;
										delay_ms(10);
										LCD_DrawRectangle(tp_dev.x[0],tp_dev.y[0],tp_dev.x[0],tp_dev.y[0]+30);
								
										FRONT_COLOR=color;
					
								     	   	 
										LCD_Fill(50,700,150,800,0xffff);
										LCD_Fill(50,780,150,800,GRAY);
										LCD_ShowString(50,720,tftlcd_data.wigth,tftlcd_data.height,16,"In..Text...");
								
										LCD_Fill(200,700,300,800,0xffff);
										LCD_Fill(200,780,300,800,GRAY);
										LCD_ShowString(200,720,tftlcd_data.wigth,tftlcd_data.height,16,"W..Text...");
								
										LCD_ShowPicture(400,590,30,24,(u8*)gImage_ret);
										_printf_(10,40,"%s",text);
					
										if(tp_dev.x[0]>=240&&tp_dev.y[0]>500&&tp_dev.x[0]<=490&&tp_dev.y[0]<=690){
											myfree(text);
											LCD_Clear(LIGHTBLUE);
											break;
										}	
										else if((tp_dev.x[0]>=200&&tp_dev.y[0]>700&&tp_dev.x[0]<=300&&tp_dev.y[0]<=890)){
																f_open(&fp,(TCHAR *)(buf),FA_OPEN_ALWAYS|FA_WRITE);
																f_printf(&fp,"%s",text);
																f_close(&fp);
										}
										else if((tp_dev.x[0]>=25&&tp_dev.y[0]>650&&tp_dev.x[0]<=175&&tp_dev.y[0]<=890)){
											LCD_Fill(0,500,480,800,LGRAY);
											LCD_Fill(10,520,110,580,0xffff);
											LCD_Fill(120,520,220,580,0xffff);
											LCD_Fill(230,520,330,580,0xffff);
											LCD_Fill(340,520,440,580,0xffff);
											
											LCD_Fill(10,600,110,660,0xffff);
											LCD_Fill(120,600,220,660,0xffff);
											LCD_Fill(230,600,330,660,0xffff);
											LCD_Fill(340,600,440,660,0xffff);
											
											LCD_Fill(10,680,110,740,0xffff);
											LCD_Fill(120,680,220,740,0xffff);
											LCD_Fill(230,680,330,740,0xffff);
											LCD_Fill(340,680,440,740,0xffff);
											FRONT_COLOR=0x0000;
											
											LCD_ShowString(10,530,tftlcd_data.wigth,tftlcd_data.height,24,"q");
											LCD_ShowString(120,530,tftlcd_data.wigth,tftlcd_data.height,24,"w");
											LCD_ShowString(230,530,tftlcd_data.wigth,tftlcd_data.height,24,"e");
											LCD_ShowString(340,530,tftlcd_data.wigth,tftlcd_data.height,24,"r");
											
											LCD_ShowString(10,600,tftlcd_data.wigth,tftlcd_data.height,24,"t");
											LCD_ShowString(120,600,tftlcd_data.wigth,tftlcd_data.height,24,"y");
											LCD_ShowString(230,600,tftlcd_data.wigth,tftlcd_data.height,24,"u");
											LCD_ShowString(340,600,tftlcd_data.wigth,tftlcd_data.height,24,"i");
											
											LCD_ShowString(10,680,tftlcd_data.wigth,tftlcd_data.height,24,"o");
											LCD_ShowString(120,680,tftlcd_data.wigth,tftlcd_data.height,24,"p");
											LCD_ShowString(230,680,tftlcd_data.wigth,tftlcd_data.height,24,"Quit");
											LCD_ShowString(340,680,tftlcd_data.wigth,tftlcd_data.height,24,"Enter");
											while(1){
							
													TP_Scanf(0);
													if(tp_dev.x[0]>=10&&tp_dev.y[0]>520&&tp_dev.x[0]<=110&&tp_dev.y[0]<=580){
														sprintf((char *)text,"%c",'q');
														_printf_(10,40,"%s",text);
													}
													else if(tp_dev.x[0]>=250&&tp_dev.y[0]>700&&tp_dev.x[0]<=300&&tp_dev.y[0]<=725){
														LCD_Clear(LIGHTBLUE);
														break;
													}
													
											}
									}
							}
					}
			}
	 }
		if(tp_dev.x[0]>=150&&tp_dev.y[0]>390&&tp_dev.x[0]<=150+90&&tp_dev.y[0]<=400+90){
			LCD_Clear(0X0000);
			ADCx_Init();
			FRONT_COLOR=0xffff;
			FRONT_COLOR=GREEN;
			LCD_Fill(0,0,300,300,0x0000);
			LCD_DrawLine(10,10,10,200);
			LCD_DrawLine(100,10,100,300);
			LCD_DrawLine(200,10,200,300);
			LCD_DrawLine(300,10,300,300);
			LCD_DrawLine(10,10,10,10);
			LCD_DrawLine(10,100,300,100);
			LCD_DrawLine(10,200,300,200);
			LCD_DrawLine(10,300,300,300);
		
			
			uint32_t indata=0;
			uint32_t temp_val=0;
			float pter=0;
			while(1){
				TP_Scanf(0);

				ADC_Cmd(ADC1,ENABLE);
				
				ADC_RegularChannelConfig(ADC1,ADC_Channel_3,1, ADC_SampleTime_239Cycles5);
				ADC_SoftwareStartConvCmd(ADC1,ENABLE);
				while(ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC )==RESET);
				ADValue=ADC_GetConversionValue(ADC1);
				
				ADC_RegularChannelConfig(ADC1,ADC_Channel_16,1, ADC_SampleTime_239Cycles5);
				ADC_SoftwareStartConvCmd(ADC1,ENABLE);
				while(ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC )==RESET);
				temp_val=ADC_GetConversionValue(ADC1);
				
				
				
				Voltage=(float)((ADValue*3.3)/4096) ;
				adc=((uint32_t)(Voltage*50));
				
				pter=(float)((temp_val*3.3)/4096);
				pter=(1.43-pter)/0.0043+25;
				pter=pter;
				
				
				
				t++;
				if(t==300){
					t=0;
					LCD_Clear(0X0000);	
					LCD_Fill(0,0,300,300,0x0000);
				}
				LCD_ShowPicture(400,590,30,24,(u8*)gImage_ret);
				if(tp_dev.x[0]>=240&&tp_dev.y[0]>500&&tp_dev.x[0]<=490&&tp_dev.y[0]<=690){
						ADC_Cmd(ADC1,DISABLE);
						TIM_Cmd(TIM5,DISABLE);
						LCD_Clear(0Xffff);
						break;
				}						

				
				FRONT_COLOR=GREEN;
				LCD_Fill(t,(300-adc/2),t+1,(300-adc/2)+1,FRONT_COLOR);
				LCD_DrawLine(10,10,10,200);
				LCD_DrawLine(100,10,100,300);
				LCD_DrawLine(200,10,200,300);
				LCD_DrawLine(300,10,300,300);
				LCD_DrawLine(10,10,10,10);
				LCD_DrawLine(10,100,300,100);
				LCD_DrawLine(10,200,300,200);
				LCD_DrawLine(10,300,300,300);
				FRONT_COLOR=0Xffff;
				FRONT_COLOR=RED;
				LCD_DrawRectangle(10,400,60,700);				LCD_Color_Fill(10,400,60,400+pter*5,FRONT_COLOR);
				my_Clear(10,700,60,750,0x0000);
				_printf_(10,710,"%d.C",(uint32_t)(pter));
				FRONT_COLOR=0Xffff;

				
				FRONT_COLOR=BLUE;
				LCD_DrawRectangle(70,400,120,700);
				LCD_Color_Fill(70,400,120,400+(uint32_t)(Voltage*75),FRONT_COLOR);
				my_Clear(70,700,125,750,0X0000);
				_printf_(70,720,"MAX:%d mV",(uint32_t)(Voltage*1000));
				FRONT_COLOR=0xffff;
				
				
				
			}
				
		}
		if(tp_dev.x[0]>=290&&tp_dev.y[0]>390&&tp_dev.x[0]<=290+90&&tp_dev.y[0]<=400+90){
				LCD_Clear(0X0000);
				BEEP_Init();
				int *ptr=(int *)mymalloc(sizeof(int));
				*ptr=0;
				FRONT_COLOR=BLUE;
				LCD_ShowString(450,0,tftlcd_data.wigth,tftlcd_data.height,24,"s");
				LCD_ShowString(450,26,tftlcd_data.wigth,tftlcd_data.height,24,"t");
				LCD_ShowString(450,48,tftlcd_data.wigth,tftlcd_data.height,24,"m");
				LCD_ShowString(450,70,tftlcd_data.wigth,tftlcd_data.height,24,"3");
				LCD_ShowString(450,98,tftlcd_data.wigth,tftlcd_data.height,24,"2");
				while(1){
						tp_dev.x[0]=0xffff;tp_dev.y[0]=0xffff;
						BEEP=0;	
						TP_Scanf(0);
						TIM_Cmd(TIM6,DISABLE);
						BEEP=0;
						LCD_Color_Fill(0,0,150,80,0XFFFF);
						LCD_Color_Fill(0,0,15,80,0XEF5B);
						while(tp_dev.x[0]>=0&&tp_dev.y[0]>0&&tp_dev.x[0]<=145&&tp_dev.y[0]<=90){
							TP_Scanf(0);
							LCD_Color_Fill(0,0,150,80,0XEF5B);
							TIM6->ARR=music[0];
							TIM_Cmd(TIM6,ENABLE);
	
						}
						delay_ms(1);
						tp_dev.x[0]=0xffff;tp_dev.y[0]=0xffff;
						TIM_Cmd(TIM6,DISABLE);
						BEEP=0;
						TP_Scanf(0);
						LCD_Color_Fill(0,81,150,160,0XFFFF);
						LCD_Color_Fill(0,81,15,160,0XEF5B);
						while(tp_dev.x[0]>=0&&tp_dev.y[0]>81&&tp_dev.x[0]<=145&&tp_dev.y[0]<=160){
							TP_Scanf(0);
							LCD_Color_Fill(0,81,150,160,0XEF5B);
							TIM6->ARR=music[1];
							TIM_Cmd(TIM6,ENABLE);
	
						}
						delay_ms(1);
						tp_dev.x[0]=0xffff;tp_dev.y[0]=0xffff;
						TIM_Cmd(TIM6,DISABLE);
						BEEP=0;
						TP_Scanf(0);
						LCD_Color_Fill(0,161,150,240,0XFFFF);
						LCD_Color_Fill(0,161,15,240,0XEF5B);
						while(tp_dev.x[0]>=0&&tp_dev.y[0]>160&&tp_dev.x[0]<=145&&tp_dev.y[0]<=240){
							TP_Scanf(0);
							LCD_Color_Fill(0,161,150,240,0XEF5B);
							TIM6->ARR=music[2];
							TIM_Cmd(TIM6,ENABLE);
	
						}
						delay_ms(1);
						tp_dev.x[0]=0xffff;tp_dev.y[0]=0xffff;
						TIM_Cmd(TIM6,DISABLE);
						BEEP=0;						
						TP_Scanf(0);
						LCD_Color_Fill(0,241,150,320,0XFFFF);
						LCD_Color_Fill(0,241,15,320,0XEF5B);
						while(tp_dev.x[0]>=0&&tp_dev.y[0]>241&&tp_dev.x[0]<=145&&tp_dev.y[0]<=320){
							TP_Scanf(0);
							LCD_Color_Fill(0,241,150,320,0XEF5B);
							TIM6->ARR=music[3];
							TIM_Cmd(TIM6,ENABLE);
	
						}
						delay_ms(1);
						tp_dev.x[0]=0xffff;tp_dev.y[0]=0xffff;						
						TIM_Cmd(TIM6,DISABLE);
						BEEP=0;
						TP_Scanf(0);
						LCD_Color_Fill(0,321,150,400,0XFFFF);
						LCD_Color_Fill(0,321,15,400,0XEF5B);
						while(tp_dev.x[0]>=0&&tp_dev.y[0]>321&&tp_dev.x[0]<=145&&tp_dev.y[0]<=400){
							TP_Scanf(0);
							LCD_Color_Fill(0,321,150,400,0XEF5B);
							TIM6->ARR=music[4];
							TIM_Cmd(TIM6,ENABLE);
	
						}
						delay_ms(1);
						tp_dev.x[0]=0xffff;tp_dev.y[0]=0xffff;
						TIM_Cmd(TIM6,DISABLE);
						BEEP=0;
						TP_Scanf(0);
						LCD_Color_Fill(0,401,150,480,0XFFFF);
						LCD_Color_Fill(0,401,15,480,0XEF5B);
						while(tp_dev.x[0]>=0&&tp_dev.y[0]>401&&tp_dev.x[0]<=145&&tp_dev.y[0]<=480){
							TP_Scanf(0);
							LCD_Color_Fill(0,401,150,480,0XEF5B);
							TIM6->ARR=music[5];
							TIM_Cmd(TIM6,ENABLE);
	
						}
						delay_ms(1);
						tp_dev.x[0]=0xffff;tp_dev.y[0]=0xffff;
						TIM_Cmd(TIM6,DISABLE);
						BEEP=0;
						TP_Scanf(0);
						TIM_Cmd(TIM6,DISABLE); 
						LCD_Color_Fill(0,481,150,560,0XFFFF);
						LCD_Color_Fill(0,481,15,560,0XEF5B);
						while(tp_dev.x[0]>=0&&tp_dev.y[0]>481&&tp_dev.x[0]<=145&&tp_dev.y[0]<=560){
							TP_Scanf(0);
							LCD_Color_Fill(0,481,150,560,0XEF5B);
							TIM6->ARR=music[6];
							TIM_Cmd(TIM6,ENABLE);
	
						}
						delay_ms(1);
						tp_dev.x[0]=0xffff;tp_dev.y[0]=0xffff;
						TIM_Cmd(TIM6,DISABLE);
						BEEP=0;
						TP_Scanf(0);
						LCD_Color_Fill(0,561,150,640,0XFFFF);
						LCD_Color_Fill(0,561,15,640,0XEF5B);
						while(tp_dev.x[0]>=0&&tp_dev.y[0]>561&&tp_dev.x[0]<=145&&tp_dev.y[0]<=640){
							TP_Scanf(0);
							LCD_Color_Fill(0,561,150,640,0XEF5B);
							TIM6->ARR=music[7];
							TIM_Cmd(TIM6,ENABLE);
	
						}
						delay_ms(1);
						tp_dev.x[0]=0xffff;tp_dev.y[0]=0xffff;
						BEEP=0;
						TP_Scanf(0);
						TIM_Cmd(TIM6,DISABLE); 
						LCD_Color_Fill(0,641,150,720,0XFFFF);
						LCD_Color_Fill(0,641,15,720,0XEF5B);
						while(tp_dev.x[0]>=0&&tp_dev.y[0]>641&&tp_dev.x[0]<=145&&tp_dev.y[0]<=720){
							TP_Scanf(0);
							LCD_Color_Fill(0,641,150,720,0XEF5B);
							TIM6->ARR=music[8];
							TIM_Cmd(TIM6,ENABLE);
	
						}
						delay_ms(1);
						tp_dev.x[0]=0xffff;tp_dev.y[0]=0xffff;
						TIM_Cmd(TIM6,DISABLE);
						BEEP=0;
						TP_Scanf(0);
						TIM_Cmd(TIM6,DISABLE); 
						LCD_Color_Fill(0,721,150,800,0XFFFF);
						LCD_Color_Fill(0,721,15,800,0XEF5B);
						while(tp_dev.x[0]>=0&&tp_dev.y[0]>721&&tp_dev.x[0]<=145 &&tp_dev.y[0]<=800){
							TP_Scanf(0);
							LCD_Color_Fill(0,721,150,800,0XEF5B);
							TIM6->ARR=music[9];
							TIM_Cmd(TIM6,ENABLE);
	
						}
						delay_ms(1);
						tp_dev.x[0]=0xffff;tp_dev.y[0]=0xffff;
						TIM_Cmd(TIM6,DISABLE);
						BEEP=0;
						TP_Scanf(0);
						TIM_Cmd(TIM6,DISABLE); 
						LCD_Color_Fill(150,0,300,80,0XFFFF);
						LCD_Color_Fill(150,0,165,80,0XEF5B);
						while(tp_dev.x[0]>=170&&tp_dev.y[0]>0&&tp_dev.x[0]<=300&&tp_dev.y[0]<=80){
							TP_Scanf(0);
							LCD_Color_Fill(150,0,300,80,0XEF5B);
							TIM6->ARR=music[10];
							TIM_Cmd(TIM6,ENABLE);
	
						}
						delay_ms(1);
						tp_dev.x[0]=0xffff;tp_dev.y[0]=0xffff;
						TIM_Cmd(TIM6,DISABLE);
						BEEP=0;
						TP_Scanf(0);
						LCD_Color_Fill(150,81,300,160,0XFFFF);
						LCD_Color_Fill(150,81,165,160,0XEF5B);
						while(tp_dev.x[0]>=170&&tp_dev.y[0]>81&&tp_dev.x[0]<=300&&tp_dev.y[0]<=160){
							LCD_Color_Fill(150,81,300,160,0XEF5B);
							TP_Scanf(0);
							TIM6->ARR=music[11];
							TIM_Cmd(TIM6,ENABLE);
						}
						delay_ms(1);
						tp_dev.x[0]=0xffff;tp_dev.y[0]=0xffff;
						TIM_Cmd(TIM6,DISABLE);
						BEEP=0;
						TP_Scanf(0);
						LCD_Color_Fill(150,161,300,240,0XFFFF);
						LCD_Color_Fill(150,161,165,240,0XEF5B);
						while(tp_dev.x[0]>=170&&tp_dev.y[0]>161&&tp_dev.x[0]<=300&&tp_dev.y[0]<=240){
							LCD_Color_Fill(150,161,300,240,0XEF5B);
							TP_Scanf(0);
							TIM6->ARR=music[12];
							TIM_Cmd(TIM6,ENABLE);
						}
						delay_ms(1);

						TIM_Cmd(TIM6,DISABLE);
						TP_Scanf(0);
						BEEP=0;
						TIM_Cmd(TIM6,DISABLE);
						LCD_Color_Fill(150,241,300,320,0XFFFF);
						LCD_Color_Fill(150,241,165,320,0XEF5B);
						while(tp_dev.x[0]>=170&&tp_dev.y[0]>241&&tp_dev.x[0]<=300&&tp_dev.y[0]<=320){
							LCD_Color_Fill(150,241,300,320,0XEF5B);
							TP_Scanf(0);
							TIM6->ARR=music[13];
							TIM_Cmd(TIM6,ENABLE);
						}
						delay_ms(1);
						TIM_Cmd(TIM6,DISABLE);
						BEEP=0;
						TP_Scanf(0);
						LCD_Color_Fill(150,321,300,400,0XFFFF);
						LCD_Color_Fill(150,321,165,400,0XEF5B);
						while(tp_dev.x[0]>=170&&tp_dev.y[0]>321&&tp_dev.x[0]<=300&&tp_dev.y[0]<=400){
							LCD_Color_Fill(150,321,300,400,0XEF5B);
							TP_Scanf(0);
							TIM6->ARR=music[14];
							TIM_Cmd(TIM6,ENABLE);
						}
						delay_ms(1);
						BEEP=0;
						TP_Scanf(0);
						LCD_Color_Fill(150,321,300,400,0XFFFF);
						LCD_Color_Fill(150,321,165,400,0XEF5B);
						while(tp_dev.x[0]>=170&&tp_dev.y[0]>321&&tp_dev.x[0]<=300&&tp_dev.y[0]<=400){
							LCD_Color_Fill(150,321,300,400,0XEF5B);
							TP_Scanf(0);
							TIM6->ARR=music[15];
							TIM_Cmd(TIM6,ENABLE);
						}
						delay_ms(1);
						TIM_Cmd(TIM6,DISABLE);
						BEEP=0;
						TP_Scanf(0);
						LCD_Color_Fill(150,401,300,480,0XFFFF);
						LCD_Color_Fill(150,401,165,480,0XEF5B);
						while(tp_dev.x[0]>=170&&tp_dev.y[0]>401&&tp_dev.x[0]<=300&&tp_dev.y[0]<=480){
							TP_Scanf(0);
							LCD_Color_Fill(150,401,300,480,0XEF5B);
							TIM6->ARR=music[16];
							TIM_Cmd(TIM6,ENABLE);
						}
						delay_ms(1);
						TIM_Cmd(TIM6,DISABLE);
						TP_Scanf(0);
						LCD_Color_Fill(150,481,300,560,0XFFFF);
						LCD_Color_Fill(150,481,165,560,0XEF5B);
						while(tp_dev.x[0]>=170&&tp_dev.y[0]>481&&tp_dev.x[0]<=300&&tp_dev.y[0]<=560){
							TP_Scanf(0);
							LCD_Color_Fill(150,481,300,560,0XEF5B);
							TIM6->ARR=music[17];
							TIM_Cmd(TIM6,ENABLE);
						}
						TP_Scanf(0);
						TIM_Cmd(TIM6,DISABLE);
						BEEP=0;
						LCD_Color_Fill(150,561,300,640,0XFFFF);
						LCD_Color_Fill(150,561,165,640,0XEF5B);
						while(tp_dev.x[0]>=170&&tp_dev.y[0]>561&&tp_dev.x[0]<=300&&tp_dev.y[0]<=640){
							TP_Scanf(0);
							LCD_Color_Fill(150,561,300,640,0XEF5B);
							TIM6->ARR=music[18];
							TIM_Cmd(TIM6,ENABLE);
						}
						TP_Scanf(0);
						TIM_Cmd(TIM6,DISABLE);
						BEEP=0;
						LCD_Color_Fill(150,641,300,720,0XFFFF);
						LCD_Color_Fill(150,641,165,720,0XEF5B);
						while(tp_dev.x[0]>=170&&tp_dev.y[0]>=641&&tp_dev.x[0]<=300&&tp_dev.y[0]<720){
							TP_Scanf(0);
							LCD_Color_Fill(150,641,300,720,0XEF5B);
							TIM6->ARR=music[19];
							TIM_Cmd(TIM6,ENABLE);
						}
						TP_Scanf(0);
						TIM_Cmd(TIM6,DISABLE);						
						BEEP=0;
						LCD_Color_Fill(150,721,300,800,0XFFFF);
						LCD_Color_Fill(150,721,165,800,0XEF5B);
						while(tp_dev.x[0]>=170&&tp_dev.y[0]>=721&&tp_dev.x[0]<=300&&tp_dev.y[0]<800){
							TP_Scanf(0);
							LCD_Color_Fill(150,721,300,800,0XEF5B);
							TIM6->ARR=music[20];
							TIM_Cmd(TIM6,ENABLE);
						}
						tp_dev.x[0]=0xffff;tp_dev.y[0]=0xffff;
						BEEP=0;
						TIM_Cmd(TIM6,DISABLE);
			}
		
		
		}
		LCD_ShowPicture(10,200,87,77,(u8*)gImage_draw);
		LCD_ShowPicture(400,590,30,24,(u8*)gImage_ret);
		LCD_ShowPicture(150,200,87,77,(u8*)gImage_clock);
		LCD_ShowPicture(290,200,70,70,(u8*)gImage_led);
		LCD_ShowPicture(10,400,88,89,(u8*)gImage_oip);
		LCD_ShowPicture(150,400,88,89,(u8*)gImage_adc);
		LCD_ShowPicture(290,400,88,89,(u8*)gImage_vo);
		_printf_((10+87)/2,200+77+10,"DRAW");
		_printf_((150+150)/2,200+77+10,"Clock");
		_printf_(290,200+70,"LCD");
		
		
		
	}
	return 0;
}

void RTC_IRQHandler(void)                       
{
	if(RTC_GetITStatus(RTC_IT_SEC) != RESET) 
	{
		
		RTC_ClearITPendingBit(RTC_IT_SEC);     
		RTC_WaitForLastTask();                 
	}
}

void RTCAlarm_IRQHandler()                   
{
	if(RTC_GetITStatus(RTC_IT_ALR) != RESET)    
	{            
		EXTI_ClearITPendingBit(EXTI_Line17);    
		RTC_ClearITPendingBit(RTC_IT_ALR);      
		RTC_WaitForLastTask();                 
	}
}


void TIM6_IRQHandler(void){
		if(TIM_GetITStatus(TIM6,TIM_IT_Update)!=RESET){
		BEEP=!BEEP;
		TIM_ClearITPendingBit(TIM6,TIM_IT_Update);
	}
}

void TIM1_CC_IRQHandler(void)
{
		TIM_ClearITPendingBit(TIM1,TIM_IT_CC1);
		IC1Value=TIM_GetCapture1(TIM1);
		IC2Value=TIM_GetCapture2(TIM1);
	
}
