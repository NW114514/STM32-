
#define NULL (void *)0
typedef unsigned int size_t;
unsigned char *address=(unsigned char *)(0x68000000);
typedef struct Block {size_t size;struct Block *s;} Block;
Block* free_list = NULL;

void initmalloc(void) {
    free_list = (Block*)address;
    free_list->size =1024*1024*1024- sizeof(Block);
    free_list->s = NULL;
}


void* mymalloc(size_t size) {
    Block *ptr = NULL,*current = free_list,*bestFit = NULL;
		bestFit = current;
		if(size==0)return NULL;
    while (current != NULL) {
        if (current->size == size) {//&&bestFit== NULL||current->size<bestFit->size
						break;
        }
				else if(current->size > size){
					bestFit->size=(bestFit->size)-size;
					bestFit->s = (struct Block*)((unsigned char*)bestFit + sizeof(Block) + (bestFit->size));
					break;
				}
				else if(current->size<size){
					size_t _size=size-(bestFit->size);
					size_t _size_=bestFit->s->size;
					Block *len=bestFit->s->s;
					bestFit->s=bestFit+sizeof(Block)+_size;
					bestFit->s->s=len;
					bestFit->size=_size_-size;
					len=NULL;
					break;
				}
        current = current->s;
    }
	if(bestFit==NULL)return NULL;	
	
	if(bestFit->size>size+sizeof(Block)){
		Block *new = (Block*)((char*)bestFit + sizeof(Block) + size);
		new->size =bestFit->size-size-sizeof(Block);
		new->s=bestFit->s;
		bestFit->s=new;
		bestFit->size=size;
	}
	else{
		if(ptr==NULL){
			free_list=bestFit->s;
		}
		else{
			ptr->s=bestFit->s;
		}
	}
	return (void *)((char*)bestFit + sizeof(Block));
}

void myfree(void *ptr){
	if(ptr==NULL)return;
	Block* block=(Block *)(((char*)ptr)-sizeof(Block)),*free=NULL;
	block->s=free_list;
	free_list=block;
	ptr=NULL;
	free=free_list;
	free->size+=free->s->size;
	free->s=free->s;
	free=free->s;
}
