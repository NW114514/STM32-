#include<stm32f10x.h>
#include<stdio.h>
#include "stm32f10x_rcc.h"
void USARTI_init(uint32_t baud){
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,ENABLE);
	GPIO_InitTypeDef tx;
	tx.GPIO_Mode=GPIO_Mode_AF_PP;
	tx.GPIO_Pin=GPIO_Pin_9;
	tx.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&tx);
	
	GPIO_InitTypeDef rx;
	rx.GPIO_Mode=GPIO_Mode_IN_FLOATING;
	rx.GPIO_Pin=GPIO_Pin_10;
	rx.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&rx);
	
	
	USART_InitTypeDef usart1;
	usart1.USART_BaudRate=baud;
	usart1.USART_Mode= USART_Mode_Rx | USART_Mode_Tx;
	usart1.USART_StopBits=USART_StopBits_1;
	usart1.USART_WordLength=USART_WordLength_8b;
	usart1.USART_HardwareFlowControl=USART_HardwareFlowControl_None;
	USART_Init(USART1,&usart1);
	USART_ITConfig(USART1,USART_IT_RXNE,DISABLE);
	USART_ClearFlag(USART1,USART_IT_RXNE);
	USART_Cmd(USART1,ENABLE);
	
	NVIC_InitTypeDef nvic;
	nvic.NVIC_IRQChannelCmd=ENABLE;
	nvic.NVIC_IRQChannel=USART1_IRQn;
	nvic.NVIC_IRQChannelPreemptionPriority=2;
	nvic.NVIC_IRQChannelSubPriority=3;
	NVIC_Init(&nvic);

}
int fputc(int ch,FILE *p){
	USART_SendData(USART1,(u8)ch);
	while(USART_GetFlagStatus(USART1,USART_FLAG_TXE)==RESET);
	return ch;
}
int fgetc(FILE *f){
	while(USART_GetFlagStatus(USART1,USART_FLAG_RXNE)==RESET);
	return (int)USART_ReceiveData(USART1);
}
