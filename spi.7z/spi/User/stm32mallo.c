
#define NULL (void *)0
typedef unsigned long long size_t;
unsigned char address[65535];
typedef struct Block {size_t size;struct Block *s;} Block;
Block* free_list = NULL;

void initmalloc(void) {
    free_list = (Block*)address;
    free_list->size =65535- sizeof(Block);
    free_list->s = NULL;
}


void* mymalloc(size_t size) {
    Block *ptr = NULL,*current = free_list,*bestFit = NULL;
    while (current != NULL) {
        if (current->size >= size&&bestFit== NULL||current->size<bestFit->size) {
  		   bestFit = current;
  		   ptr=current;
        }
        current = current->s;
    }
	if(bestFit==NULL)return NULL;	
	
	if(bestFit->size>size+sizeof(Block)){
		Block *new = (Block*)((char*)bestFit + sizeof(Block) + size);
		new->size =bestFit->size-size-sizeof(Block);
		new->s=bestFit->s;
		bestFit->s=new;
		bestFit->size=size;
	}
	else{
		if(ptr==NULL){
			free_list=bestFit->s;
		}
		else{
			ptr->s=bestFit->s;
		}
	}
	return (void *)((char*)bestFit + sizeof(Block));
}

void myfree(void *ptr){
	if(ptr==NULL)return;
	Block* block=(Block *)(((char*)ptr)-sizeof(Block));
	block->s=free_list;
	free_list=block;
	ptr=NULL;
}

