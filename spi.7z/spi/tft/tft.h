#ifndef _tftlcd_H
#define _tftlcd_H	
#include<stm32f10x.h>
#include<beep.h>
#define TFTLCD_BASE ((uint32_t)(0x6C000000 | 0x000007FE))
#define TFTLCD      ((TFTLCD_TypeDef *)TFTLCD_BASE)
#define LCD_LED PBout(0);
#define TFTLCD_DIR 0
//������ɫ
#define WHITE         	 0xFFFF
#define BLACK         	 0x0000	  
#define BLUE         	 	0x001F
#define BRED             0XF81F
#define GRED 				 		0XFFE0
#define GBLUE			 			0X07FF
#define RED           	 0xF800
#define MAGENTA       	 0xF81F
#define GREEN         	 0x07E0
#define CYAN          	 0x7FFF
#define YELLOW        	 0xFFE0
#define BROWN 			 0XBC40 //��ɫ
#define BRRED 			 0XFC07 //�غ�ɫ
#define GRAY  			 0X8430 //��ɫ
#define DARKBLUE      	 0X01CF	//����ɫ
#define LIGHTBLUE      	 0X7D7C	//ǳ��ɫ  
#define GRAYBLUE       	 0X5458 //����ɫ
#define LIGHTGREEN     	 0X841F //ǳ��ɫ
#define LIGHTGRAY        0XEF5B //ǳ��ɫ(PANNEL)
#define LGRAY 			 0XC618 //ǳ��ɫ(PANNEL),���屳��ɫ
#define LGRAYBLUE        0XA651 //ǳ����ɫ(�м����ɫ)
#define LBBLUE           0X2B12 //ǳ����ɫ(ѡ����Ŀ�ķ�ɫ)
typedef struct{
	uint16_t LCD_CMD;
	uint16_t LCD_DATA;
}TFTLCD_TypeDef;
typedef struct{
	uint16_t wigth;
	uint16_t height;
	uint16_t id;
	uint16_t dir;
}_tdtlcd_data;
void TFTLCD_GPIO_Init(void);
void TFTLCD_FSMC_Init(void);
void LCD_WriteCmd(uint16_t cmd);
void LCD_WriteData(uint16_t data);
void LCD_WriteCmdData(uint16_t cmd,uint16_t data);
uint32_t	LCD_RGBColor_Change(uint16_t color);
void LCD_WriteData_Color(uint16_t color);
uint16_t LCD_ReadData(void);
void LCD_Display_Dir(uint8_t dir);
void LCD_Set_Window(u16 sx,u16 sy,u16 width,u16 height);
uint16_t LCD_ReadPoint(uint16_t x,uint16_t y);
void LCD_SSD_BackLightSet(uint8_t pwm);
void LCD_Fill(u16 xState,u16 yState,u16 xEnd,u16 yEnd,u16 color);
void LCD_Color_Fill(u16 sx,u16 sy,u16 ex,u16 ey,u16 color);
void LCD_DrawPoint(u16 x,u16 y);
void LCD_DrawFRONT_COLOR(u16 x,u16 y,u16 color);
void LCD_DrawLine(u16 x1, u16 y1, u16 x2, u16 y2) ;
void LCD_DrawLine_Color(u16 x1, u16 y1, u16 x2, u16 y2,u16 color);
void LCD_DrowSign(uint16_t x, uint16_t y, uint16_t color)  ;
void LCD_DrawRectangle(u16 x1, u16 y1, u16 x2, u16 y2);
void LCD_Draw_Circle(u16 x0,u16 y0,u8 r);
void LCD_ShowChar(u16 x,u16 y,u8 num,u8 size,u8 mode)  ;
u32 LCD_Pow(u8 m,u8 n)	 ;
void LCD_ShowNum(u16 x,u16 y,u32 num,u8 len,u8 size);
void LCD_ShowxNum(u16 x,u16 y,u32 num,u8 len,u8 size,u8 mode);
void LCD_ShowString(u16 x,u16 y,u16 width,u16 height,u8 size,u8 *p);
void LCD_ShowFontHZ(u16 x, u16 y, u8 *cn)	 ;
void LCD_ShowFontHZ(u16 x, u16 y, u8 *cn);
void LCD_ShowPicture(u16 x, u16 y, u16 wide, u16 high,u8 *pic);
void LCD_Clear(u16 color);
void TFTLCD_Init(void);
void SysTick_Init(u8 SYSCLK);								   
void delay_us(u32 nus);
void delay_ms(u16 nms);
extern _tdtlcd_data tftlcd_data;
extern uint16_t  FRONT_COLOR; 
extern uint16_t  BACK_COLOR; 
#endif  
