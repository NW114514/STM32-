#include<tft.h>
#include<font.h>
static u8  fac_us=0;							 
static u16 fac_ms=0;						
_tdtlcd_data tftlcd_data;
uint16_t  FRONT_COLOR; 
uint16_t  BACK_COLOR;


void SysTick_Init(u8 SYSCLK)
{
	SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK_Div8); 
	fac_us=SYSCLK/8;					
	fac_ms=(u16)fac_us*1000;				   
}								    
	    								   
void delay_us(u32 nus)
{		
	u32 temp;	    	 
	SysTick->LOAD=nus*fac_us; 					  		 
	SysTick->VAL=0x00;        					
	SysTick->CTRL|=SysTick_CTRL_ENABLE_Msk ;	
	do
	{
		temp=SysTick->CTRL;
	}while((temp&0x01)&&!(temp&(1<<16)));	
	SysTick->CTRL&=~SysTick_CTRL_ENABLE_Msk;	
	SysTick->VAL =0X00;      					
}
void delay_ms(u16 nms)
{	 		  	  
	u32 temp;		   
	SysTick->LOAD=(u32)nms*fac_ms;			
	SysTick->VAL =0x00;					
	SysTick->CTRL|=SysTick_CTRL_ENABLE_Msk ;	
	do
	{
		temp=SysTick->CTRL;
	}while((temp&0x01)&&!(temp&(1<<16)));	
	SysTick->CTRL&=~SysTick_CTRL_ENABLE_Msk;	
	SysTick->VAL =0X00;       				  	    
} 


void TFTLCD_Init(void){
	TFTLCD_GPIO_Init();
	TFTLCD_FSMC_Init();
	DMA_init();
	delay_ms(50);
	LCD_WriteCmd(0Xd3);	
	tftlcd_data.id=TFTLCD->LCD_DATA;	 
	tftlcd_data.id=TFTLCD->LCD_DATA;  
	tftlcd_data.id=TFTLCD->LCD_DATA;  
	tftlcd_data.id<<=8;
	tftlcd_data.id|=TFTLCD->LCD_DATA;
	LCD_WriteCmd(0xFF);
	LCD_WriteData(0xFF);
	LCD_WriteData(0x98);
	LCD_WriteData(0x06);

	LCD_WriteCmd(0xBA);
	LCD_WriteData(0x60);

	LCD_WriteCmd(0xBC);
	LCD_WriteData(0x03);
	LCD_WriteData(0x0E);
	LCD_WriteData(0x03);
	LCD_WriteData(0x63);
	LCD_WriteData(0x01);
	LCD_WriteData(0x01);
	LCD_WriteData(0x1B);
	LCD_WriteData(0x12);
	LCD_WriteData(0x6F);
	LCD_WriteData(0x00);
	LCD_WriteData(0x00);
	LCD_WriteData(0x00);
	LCD_WriteData(0x01);
	LCD_WriteData(0x01);
	LCD_WriteData(0x03);
	LCD_WriteData(0x02);
	LCD_WriteData(0xFF);
	LCD_WriteData(0xF2);
	LCD_WriteData(0x01);
	LCD_WriteData(0x00);
	LCD_WriteData(0xC0);

	LCD_WriteCmd(0xBD);
	LCD_WriteData(0x02);
	LCD_WriteData(0x13);
	LCD_WriteData(0x45);
	LCD_WriteData(0x67);
	LCD_WriteData(0x45);
	LCD_WriteData(0x67);
	LCD_WriteData(0x01);
	LCD_WriteData(0x23);

	LCD_WriteCmd(0xBE);
	LCD_WriteData(0x01);
	LCD_WriteData(0x22);
	LCD_WriteData(0x22);
	LCD_WriteData(0xDC);
	LCD_WriteData(0xBA);
	LCD_WriteData(0x67);
	LCD_WriteData(0x22);
	LCD_WriteData(0x22);
	LCD_WriteData(0x22);

	LCD_WriteCmd(0xC7);
	LCD_WriteData(0x66);

	LCD_WriteCmd(0xED);
	LCD_WriteData(0x7F);
	LCD_WriteData(0x0F);
	LCD_WriteData(0x00);

	LCD_WriteCmd(0xC0);
	LCD_WriteData(0x03);
	LCD_WriteData(0x0B);
	LCD_WriteData(0x00);
	
	LCD_WriteCmd(0XF5);
	LCD_WriteData(0x20);
	LCD_WriteData(0x43);
	LCD_WriteData(0x00);

	LCD_WriteCmd(0xEE);
	LCD_WriteData(0x0A);
	LCD_WriteData(0x1B);
	LCD_WriteData(0x5F);
	LCD_WriteData(0x40);
	LCD_WriteData(0x28);
	LCD_WriteData(0x38);
	LCD_WriteData(0x02);
	LCD_WriteData(0x2B);
	LCD_WriteData(0x50);
	LCD_WriteData(0x00);
	LCD_WriteData(0x80);

	LCD_WriteCmd(0xFC);
	LCD_WriteData(0x08);

	LCD_WriteCmd(0xDF);
	LCD_WriteData(0x00);
	LCD_WriteData(0x00);
	LCD_WriteData(0x00);
	LCD_WriteData(0x00);
	LCD_WriteData(0x00);
	LCD_WriteData(0x20);

	LCD_WriteCmd(0xF3);
	LCD_WriteData(0x74);

	LCD_WriteCmd(0xB4);
	LCD_WriteData(0x02);
	LCD_WriteData(0x02);
	LCD_WriteData(0x02);

	LCD_WriteCmd(0xF7);
	LCD_WriteData(0x82);
	
	LCD_WriteCmd(0xB1);
	LCD_WriteData(0x00);
	LCD_WriteData(0x13);
	LCD_WriteData(0x13);

	LCD_WriteCmd(0xF2);
	LCD_WriteData(0x41);
	LCD_WriteData(0x04);
	LCD_WriteData(0x41);
	LCD_WriteData(0x28);

	LCD_WriteCmd(0xC1);
	LCD_WriteData(0x17);
	LCD_WriteData(0x78);
	LCD_WriteData(0x7B);
	LCD_WriteData(0x20);

	LCD_WriteCmd(0xE0);
	LCD_WriteData(0x00);
	LCD_WriteData(0x02);
	LCD_WriteData(0x0C);
	LCD_WriteData(0x0F);
	LCD_WriteData(0x11);
	LCD_WriteData(0x1C);
	LCD_WriteData(0xC8);
	LCD_WriteData(0x07);
	LCD_WriteData(0x03);
	LCD_WriteData(0x08);
	LCD_WriteData(0x03);
	LCD_WriteData(0x0D);
	LCD_WriteData(0x0C);
	LCD_WriteData(0x31);
	LCD_WriteData(0x2C);
	LCD_WriteData(0x00);

	LCD_WriteCmd(0xE1);
	LCD_WriteData(0x00);
	LCD_WriteData(0x02);
	LCD_WriteData(0x08);
	LCD_WriteData(0x0E);
	LCD_WriteData(0x12);
	LCD_WriteData(0x17);
	LCD_WriteData(0x7C);
	LCD_WriteData(0x0A);
	LCD_WriteData(0x03);
	LCD_WriteData(0x09);
	LCD_WriteData(0x06);
	LCD_WriteData(0x0C);
	LCD_WriteData(0x0C);
	LCD_WriteData(0x2E);
	LCD_WriteData(0x2A);
	LCD_WriteData(0x00);

	LCD_WriteCmd(0x35);
	LCD_WriteData(0x00);

	LCD_WriteCmd(0x36); 
	LCD_WriteData(0xC0);

	LCD_WriteCmd(0x3A); 
	LCD_WriteData(0x55);

	LCD_WriteCmd(0x11);
	delay_ms(120);

	LCD_WriteCmd(0x29);
	LCD_Display_Dir(TFTLCD_DIR);
	LCD_Clear(WHITE);
}

void TFTLCD_GPIO_Init(void){
	GPIO_InitTypeDef gpio;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB|RCC_APB2Periph_GPIOD|RCC_APB2Periph_GPIOE|RCC_APB2Periph_GPIOG,ENABLE);
	gpio.GPIO_Pin=GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_14|GPIO_Pin_15;
	gpio.GPIO_Mode=GPIO_Mode_AF_PP;
	gpio.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOD,&gpio);
	
	gpio.GPIO_Pin=GPIO_Pin_7|GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;
	gpio.GPIO_Mode=GPIO_Mode_AF_PP;
	gpio.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOE,&gpio);
	
	gpio.GPIO_Pin=GPIO_Pin_0|GPIO_Pin_12;
	gpio.GPIO_Mode=GPIO_Mode_AF_PP;
	gpio.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOG,&gpio);
	
	gpio.GPIO_Pin=GPIO_Pin_0;
	gpio.GPIO_Mode=GPIO_Mode_AF_PP;
	gpio.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&gpio);
}
void TFTLCD_FSMC_Init(void){
		FSMC_NORSRAMInitTypeDef  FSMC_NORSRAMInitStructure;
  	FSMC_NORSRAMTimingInitTypeDef  FSMC_ReadTimingInitStructure; 
		FSMC_NORSRAMTimingInitTypeDef  FSMC_WriteTimingInitStructure;
  	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_FSMC,ENABLE);	
		FSMC_ReadTimingInitStructure.FSMC_AddressSetupTime = 0x01;	
  	FSMC_ReadTimingInitStructure.FSMC_AddressHoldTime = 0x00;	 	
  	FSMC_ReadTimingInitStructure.FSMC_DataSetupTime = 0x0f;		 
  	FSMC_ReadTimingInitStructure.FSMC_BusTurnAroundDuration = 0x00;
  	FSMC_ReadTimingInitStructure.FSMC_CLKDivision = 0x00;
  	FSMC_ReadTimingInitStructure.FSMC_DataLatency = 0x00;
  	FSMC_ReadTimingInitStructure.FSMC_AccessMode = FSMC_AccessMode_A;	 //ģʽA 
	
		FSMC_WriteTimingInitStructure.FSMC_AddressSetupTime = 0x15;	 
  	FSMC_WriteTimingInitStructure.FSMC_AddressHoldTime = 0x15;	
  	FSMC_WriteTimingInitStructure.FSMC_DataSetupTime = 0x05;		 
  	FSMC_WriteTimingInitStructure.FSMC_BusTurnAroundDuration = 0x00;
  	FSMC_WriteTimingInitStructure.FSMC_CLKDivision = 0x00;
  	FSMC_WriteTimingInitStructure.FSMC_DataLatency = 0x00;
  	FSMC_WriteTimingInitStructure.FSMC_AccessMode = FSMC_AccessMode_A;	 

 
  	FSMC_NORSRAMInitStructure.FSMC_Bank = FSMC_Bank1_NORSRAM4;
  	FSMC_NORSRAMInitStructure.FSMC_DataAddressMux = FSMC_DataAddressMux_Disable; 
  	FSMC_NORSRAMInitStructure.FSMC_MemoryType =FSMC_MemoryType_SRAM;
  	FSMC_NORSRAMInitStructure.FSMC_MemoryDataWidth = FSMC_MemoryDataWidth_16b;  
  	FSMC_NORSRAMInitStructure.FSMC_BurstAccessMode =FSMC_BurstAccessMode_Disable;
  	FSMC_NORSRAMInitStructure.FSMC_WaitSignalPolarity = FSMC_WaitSignalPolarity_Low;
		FSMC_NORSRAMInitStructure.FSMC_AsynchronousWait=FSMC_AsynchronousWait_Disable; 
  	FSMC_NORSRAMInitStructure.FSMC_WrapMode = FSMC_WrapMode_Disable;   
  	FSMC_NORSRAMInitStructure.FSMC_WaitSignalActive = FSMC_WaitSignalActive_BeforeWaitState;  
  	FSMC_NORSRAMInitStructure.FSMC_WriteOperation = FSMC_WriteOperation_Enable;
  	FSMC_NORSRAMInitStructure.FSMC_WaitSignal = FSMC_WaitSignal_Disable;   
  	FSMC_NORSRAMInitStructure.FSMC_ExtendedMode = FSMC_ExtendedMode_Enable; 
  	FSMC_NORSRAMInitStructure.FSMC_WriteBurst = FSMC_WriteBurst_Disable; 
  	FSMC_NORSRAMInitStructure.FSMC_ReadWriteTimingStruct = &FSMC_ReadTimingInitStructure; 
  	FSMC_NORSRAMInitStructure.FSMC_WriteTimingStruct = &FSMC_WriteTimingInitStructure; 

  	FSMC_NORSRAMInit(&FSMC_NORSRAMInitStructure); 

		FSMC_NORSRAMCmd(FSMC_Bank1_NORSRAM4, ENABLE);  
}
void LCD_WriteCmd(uint16_t cmd){
	TFTLCD->LCD_CMD=cmd;
}

void LCD_WriteData(uint16_t data){
			TFTLCD->LCD_DATA=data;
}
void LCD_WriteCmdData(uint16_t cmd,uint16_t data){
	LCD_WriteCmd(cmd);
	LCD_WriteData(data);
}
uint32_t	LCD_RGBColor_Change(uint16_t color){
	uint8_t r,g,b=0;
	r=(color>>11)&0x1f;
	g=(color>>5)&0x3f;
	b=color&0x1f;
	return ((r<<13)|(g<<6)|(b<<1));
}
void LCD_WriteData_Color(uint16_t color){
	TFTLCD->LCD_DATA=color;
}
uint16_t LCD_ReadData(void){
	return TFTLCD->LCD_DATA;
}
void LCD_Display_Dir(uint8_t dir){
	if(dir==0){
		LCD_WriteCmdData(0x36,0x00);
		tftlcd_data.height=800;
		tftlcd_data.wigth=480;
	}
	else{
		LCD_WriteCmdData(0x36,0x68);
		tftlcd_data.height=480;
		tftlcd_data.wigth=800;
	}
}
void LCD_Set_Window(u16 sx,u16 sy,u16 width,u16 height)
{   
	LCD_WriteCmd(0x2A);
	LCD_WriteData(sx/256);   
	LCD_WriteData(sx%256); 	 
	LCD_WriteData(width/256); 
	LCD_WriteData(width%256);
	
	LCD_WriteCmd(0x2B);
	LCD_WriteData(sy/256);  
	LCD_WriteData(sy%256);
	LCD_WriteData(height/256); 
	LCD_WriteData(height%256); 	

	LCD_WriteCmd(0x2C);
	
}
uint16_t LCD_ReadPoint(uint16_t x,uint16_t y){
	uint16_t r=0,g=0,b=0;
	if(x>=tftlcd_data.wigth||y>=tftlcd_data.height)return 0;	
	LCD_Set_Window(x, y, x, y);
		LCD_WriteCmd(0X2e);
	r=LCD_ReadData();								 		 				    
	r=LCD_ReadData();							
	b=LCD_ReadData();
	g=LCD_ReadData(); 
	return (((r>>11)<<11)|((g>>10)<<5)|(b>>11));
}
void LCD_SSD_BackLightSet(uint8_t pwm){
	LCD_WriteCmd(0XBE);
	LCD_WriteData(0X0E);
	LCD_WriteData(pwm*2.55);
	LCD_WriteData(0X01);
	LCD_WriteData(0Xff);
	LCD_WriteData(0X00);
	LCD_WriteData(0X00);
}
void LCD_Fill(u16 xState,u16 yState,u16 xEnd,u16 yEnd,u16 color)
{          
	uint16_t temp;

    if((xState > xEnd) || (yState > yEnd))
    {
        return;
    }   
	LCD_Set_Window(xState, yState, xEnd, yEnd); 
    xState = xEnd - xState + 1;
	yState = yEnd - yState + 1;

	while(xState--)
	{
	 	temp = yState;
		while (temp--)
	 	{			
			LCD_WriteData_Color(color);	
		}
	}	
} 


void LCD_Color_Fill(u16 sx,u16 sy,u16 ex,u16 ey,u16 color)
{  
	DMA_init();
	DMA_InitTypeDef DMA_InitStructure;
	DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)&(TFTLCD->LCD_DATA);
  DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)&color;
  DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;
	DMA_InitStructure.DMA_BufferSize = (uint16_t)(ex-sx)*(ey-sy);
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Disable;
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
  DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
  DMA_InitStructure.DMA_Priority = DMA_Priority_High;
  DMA_InitStructure.DMA_M2M = DMA_M2M_Enable ;
  DMA_Init(DMA1_Channel1, &DMA_InitStructure);
	LCD_Set_Window(sx,sy,ex-1,ey-1);
  DMA_Cmd(DMA1_Channel1,ENABLE);
	while(DMA_GetFlagStatus(DMA1_FLAG_TC1)==RESET);
  DMA_ClearFlag(DMA1_FLAG_HT1);
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, DISABLE);
}
void LCD_DrawPoint(u16 x,u16 y)
{
	LCD_Set_Window(x, y, x, y);  
	TFTLCD->LCD_DATA=(FRONT_COLOR);	
}


void LCD_DrawFRONT_COLOR(u16 x,u16 y,u16 color)
{	   
	LCD_Set_Window(x, y, x, y);
	TFTLCD->LCD_DATA=(color);	
} 


void LCD_DrawLine(u16 x1, u16 y1, u16 x2, u16 y2)
{
	u16 t; 
	int xerr=0,yerr=0,delta_x,delta_y,distance; 
	int incx,incy,uRow,uCol; 
	delta_x=x2-x1; 
	delta_y=y2-y1; 
	uRow=x1; 
	uCol=y1; 
	if(delta_x>0)incx=1; 
	else if(delta_x==0)incx=0;
	else {incx=-1;delta_x=-delta_x;} 
	if(delta_y>0)incy=1; 
	else if(delta_y==0)incy=0;
	else{incy=-1;delta_y=-delta_y;} 
	if( delta_x>delta_y)distance=delta_x; 
	else distance=delta_y; 
	for(t=0;t<=distance+1;t++ )
	{  
		LCD_DrawPoint(uRow,uCol);
		xerr+=delta_x ; 
		yerr+=delta_y ; 
		if(xerr>distance) 
		{ 
			xerr-=distance; 
			uRow+=incx; 
		} 
		if(yerr>distance) 
		{ 
			yerr-=distance; 
			uCol+=incy; 
		} 
	}  
} 

void LCD_DrawLine_Color(u16 x1, u16 y1, u16 x2, u16 y2,u16 color)
{
	u16 t; 
	int xerr=0,yerr=0,delta_x,delta_y,distance; 
	int incx,incy,uRow,uCol; 
	delta_x=x2-x1;
	delta_y=y2-y1; 
	uRow=x1; 
	uCol=y1; 
	if(delta_x>0)incx=1; 
	else if(delta_x==0)incx=0;
	else {incx=-1;delta_x=-delta_x;} 
	if(delta_y>0)incy=1; 
	else if(delta_y==0)incy=0; 
	else{incy=-1;delta_y=-delta_y;} 
	if( delta_x>delta_y)distance=delta_x; 
	else distance=delta_y; 
	for(t=0;t<=distance+1;t++ )
	{  
		LCD_DrawFRONT_COLOR(uRow,uCol,color);
		xerr+=delta_x ; 
		yerr+=delta_y ; 
		if(xerr>distance) 
		{ 
			xerr-=distance; 
			uRow+=incx; 
		} 
		if(yerr>distance) 
		{ 
			yerr-=distance; 
			uCol+=incy; 
		} 
	}  
} 
void LCD_DrowSign(uint16_t x, uint16_t y, uint16_t color)
{
    uint8_t i;


    LCD_Set_Window(x-1, y-1, x+1, y+1);
    for(i=0; i<9; i++)
    {
		LCD_WriteData_Color(color);   
    }


    LCD_Set_Window(x-4, y, x+4, y);
    for(i=0; i<9; i++)
    {
		LCD_WriteData_Color(color); 
    }


    LCD_Set_Window(x, y-4, x, y+4);
    for(i=0; i<9; i++)
    {
		LCD_WriteData_Color(color); 
    }
}
void LCD_DrawRectangle(u16 x1, u16 y1, u16 x2, u16 y2)
{
	LCD_DrawLine(x1,y1,x2,y1);
	LCD_DrawLine(x1,y1,x1,y2);
	LCD_DrawLine(x1,y2,x2,y2);
	LCD_DrawLine(x2,y1,x2,y2);
}
void LCD_Draw_Circle(u16 x0,u16 y0,u8 r)
{
	int a,b;
	int di;
	a=0;b=r;	  
	di=3-(r<<1);      
	while(a<=b)
	{
		LCD_DrawPoint(x0+a,y0-b);             //5
 		LCD_DrawPoint(x0+b,y0-a);             //0           
		LCD_DrawPoint(x0+b,y0+a);             //4               
		LCD_DrawPoint(x0+a,y0+b);             //6 
		LCD_DrawPoint(x0-a,y0+b);             //1       
 		LCD_DrawPoint(x0-b,y0+a);             
		LCD_DrawPoint(x0-a,y0-b);             //2             
  	LCD_DrawPoint(x0-b,y0-a);             //7     	         
		a++;
   
		if(di<0)di +=4*a+6;	  
		else
		{
			di+=10+4*(a-b);   
			b--;
		} 						    
	}
} 
void LCD_ShowChar(u16 x,u16 y,u8 num,u8 size,u8 mode)
{  							  
    u8 temp,t1,t;
	u16 y0=y;
	u8 csize=(size/8+((size%8)?1:0))*(size/2);		//�õ�����һ���ַ���Ӧ������ռ���ֽ���	
 	num=num-' ';//�õ�ƫ�ƺ��ֵ��ASCII�ֿ��Ǵӿո�ʼȡģ������-' '���Ƕ�Ӧ�ַ����ֿ⣩
	for(t=0;t<csize;t++)
	{   
		if(size==12)temp=ascii_1206[num][t]; 	 	//����1206����
		else if(size==16)temp=ascii_1608[num][t];	//����1608����
		else if(size==24)temp=ascii_2412[num][t];	//����2412����
		else return;								//û�е��ֿ�
		for(t1=0;t1<8;t1++)
		{			    
			if(temp&0x80)LCD_DrawFRONT_COLOR(x,y,FRONT_COLOR);
			else if(mode==0)LCD_DrawFRONT_COLOR(x,y,BACK_COLOR);
			temp<<=1;
			y++;
			if(y>=tftlcd_data.height)return;		//��������
			if((y-y0)==size)
			{
				y=y0;
				x++;
				if(x>=tftlcd_data.wigth)return;	//��������
				break;
			}
		}  	 
	}  	    	   	 	  
}   

u32 LCD_Pow(u8 m,u8 n)
{
	u32 result=1;	 
	while(n--)result*=m;    
	return result;
}			 

void LCD_ShowNum(u16 x,u16 y,u32 num,u8 len,u8 size)
{         	
	u8 t,temp;
	u8 enshow=0;						   
	for(t=0;t<len;t++)
	{
		temp=(num/LCD_Pow(10,len-t-1))%10;
		if(enshow==0&&t<(len-1))
		{
			if(temp==0)
			{
				LCD_ShowChar(x+(size/2)*t,y,' ',size,0);
				continue;
			}else enshow=1; 
		 	 
		}
	 	LCD_ShowChar(x+(size/2)*t,y,temp+'0',size,0); 
	}
} 

//��ʾ����,��λΪ0,������ʾ
//x,y:�������
//num:��ֵ(0~999999999);	 
//len:����(��Ҫ��ʾ��λ��)
//size:�����С
//mode:
//[7]:0,�����;1,���0.
//[6:1]:����
//[0]:0,�ǵ�����ʾ;1,������ʾ.
void LCD_ShowxNum(u16 x,u16 y,u32 num,u8 len,u8 size,u8 mode)
{  
	u8 t,temp;
	u8 enshow=0;						   
	for(t=0;t<len;t++)
	{
		temp=(num/LCD_Pow(10,len-t-1))%10;
		if(enshow==0&&t<(len-1))
		{
			if(temp==0)
			{
				if(mode&0X80)LCD_ShowChar(x+(size/2)*t,y,'0',size,mode&0X01);  
				else LCD_ShowChar(x+(size/2)*t,y,' ',size,mode&0X01);  
 				continue;
			}else enshow=1; 
		 	 
		}
	 	LCD_ShowChar(x+(size/2)*t,y,temp+'0',size,mode&0X01); 
	}
} 
  
void LCD_ShowString(u16 x,u16 y,u16 width,u16 height,u8 size,u8 *p)
{         
	u8 x0=x;
	width+=x;
	height+=y;
    while((*p<='~')&&(*p>=' '))//�ж��ǲ��ǷǷ��ַ�!
    {       
        if(x>=width){x=x0;y+=size;}
        if(y>=height)break;//�˳�
        LCD_ShowChar(x,y,*p,size,1);
        x+=size/2;
        p++;
    }  
}

#if 0
void LCD_ShowFontHZ(u16 x, u16 y, u8 *cn)	 
{  
	u8 i, j, wordNum;
	u16 color;
	while (*cn != '\0')
	{
		LCD_Set_Window(x, y, x+31, y+28);
		for (wordNum=0; wordNum<20; wordNum++)
		{	//wordNumɨ���ֿ������
			if ((CnChar32x29[wordNum].Index[0]==*cn)
			     &&(CnChar32x29[wordNum].Index[1]==*(cn+1)))
			{
				for(i=0; i<116; i++) 
				{	//MSK��λ��
					color=CnChar32x29[wordNum].Msk[i];
					for(j=0;j<8;j++) 
					{
						if((color&0x80)==0x80)
						{
							LCD_WriteData_Color(FRONT_COLOR); 						
						} 						
						else
						{
							LCD_WriteData_Color(BACK_COLOR); 
						} 
						color<<=1;
					}//for(j=0;j<8;j++)����
				}    
			}
		} //for (wordNum=0; wordNum<20; wordNum++)���� 	
		cn += 2;
		x += 32;
	}
}
#endif


#if 1
void LCD_ShowFontHZ(u16 x, u16 y, u8 *cn)
{
	u8 i, j, wordNum;
	u16 color;
	u16 x0=x; 
	u16 y0=y; 
	while (*cn != '\0')
	{
		for (wordNum=0; wordNum<20; wordNum++)
		{	//wordNumɨ���ֿ������
			if ((CnChar32x29[wordNum].Index[0]==*cn)
			     &&(CnChar32x29[wordNum].Index[1]==*(cn+1)))
			{
				for(i=0; i<116; i++) 
				{	//MSK��λ��
					color=CnChar32x29[wordNum].Msk[i];
					for(j=0;j<8;j++) 
					{
						if((color&0x80)==0x80)
						{
							LCD_DrawFRONT_COLOR(x,y,FRONT_COLOR);
						} 						
						else
						{
							LCD_DrawFRONT_COLOR(x,y,BACK_COLOR);
						} 
						color<<=1;
						x++;
						if((x-x0)==32)
						{
							x=x0;
							y++;
							if((y-y0)==29)
							{
								y=y0;
							}
						}
					}
				}	
			}
			
		} 
		cn += 2;
		x += 32;
		x0=x;
	}
}	
#endif

void LCD_ShowPicture(u16 x, u16 y, u16 wide, u16 high,u8 *pic)
{
	uint64_t tmp=0;
	DMA_InitTypeDef DMA_InitStructure;
	uint16_t temp=0;
	LCD_Set_Window(x, y, x+wide-1, y+high-1);
		for(uint32_t i=0;i<wide*high;i++){
			temp= (pic[tmp + 1]<<8)|pic[tmp];
			tmp += 2;
			TFTLCD->LCD_DATA=temp;
		}
		
}

void LCD_Clear(u16 color) {
    LCD_Set_Window(0, 0, 480-1, 800-1);
		LCD_Color_Fill(0,0,120,400,color);
		LCD_Color_Fill(0,400,120,800,color);
	
		LCD_Color_Fill(0,120,120,800,color);
		LCD_Color_Fill(0,240,120,400,color);
	
		LCD_Color_Fill(120,0,240,400,color);
		LCD_Color_Fill(120,400,240,800,color);
	
		LCD_Color_Fill(240,0,360,400,color);
		LCD_Color_Fill(240,400,360,800,color);
	
		LCD_Color_Fill(360,0,480,400,color);
		LCD_Color_Fill(360,400,480,800,color);
	}