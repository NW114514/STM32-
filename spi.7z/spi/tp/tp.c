#include<beep.h>
#include<tft.h>
#include<iic.h>
#include<tp.h>
#include<stdio.h>
#define CST_RST    				PFout(11)	
#define CST_INT    				PFin(10)


_m_tp_dev tp_dev={
	TP_Init,
	CST716_Scanf,
	NULL,
	0,
	0,
	0,
	0,
};
u8 CST716_WR_Reg(u16 reg,u8 *buf,u8 len)
{
	u8 i;
	u8 ret=0;
	IIC_Start();	 
	IIC_Send_Byte(CST_CMD_WR);	//����д���� 	 
	IIC_Wait_Ack(); 	 										  		   
	IIC_Send_Byte(reg&0XFF);   	//���͵�8λ��ַ
	IIC_Wait_Ack();  
	for(i=0;i<len;i++)
	{	   
    	IIC_Send_Byte(buf[i]);  	//������
		ret=IIC_Wait_Ack();
		if(ret)break;  
	}
    IIC_Stop();					//����һ��ֹͣ����	    
	return ret; 
}
void CST716_RD_Reg(u16 reg,u8 *buf,u8 len)
{
	u8 i; 
 	IIC_Start();	
 	IIC_Send_Byte(CST_CMD_WR);    
	IIC_Wait_Ack(); 	 										  		   
	IIC_Send_Byte(reg&0XFF);   	
	IIC_Wait_Ack();  
 	IIC_Start();  	 	   
	IIC_Send_Byte(CST_CMD_RD);  		   
	IIC_Wait_Ack();	   
	for(i=0;i<len;i++)
	{	   
    	buf[i]=IIC_Read_Byte(i==(len-1)?0:1); 
	} 
    IIC_Stop();  
} 
void TP_Init(void){

	

	uint8_t temp[5]={0};
	GPIO_InitTypeDef gpio;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOF,ENABLE);
	gpio.GPIO_Mode=GPIO_Mode_Out_PP;
	gpio.GPIO_Pin=GPIO_Pin_11;
	gpio.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOF,&gpio);

	GPIO_SetBits(GPIOF,GPIO_Pin_11);
	
	gpio.GPIO_Mode=GPIO_Mode_IPU;
	gpio.GPIO_Pin=GPIO_Pin_10;
	GPIO_Init(GPIOF,&gpio);
	
	GPIO_SetBits(GPIOF,GPIO_Pin_10);
	
	IIC_Init();
	CST_RST=0;
	delay_ms(20);
	CST_RST=1;
	delay_ms(50);
	
	CST716_RD_Reg(0xA7,&temp[0],1);
	printf("temp[0]=%d\r\n",temp[0]);
	
	CST716_WR_Reg(CST_DEVIDE_MODE,temp,1);	 
	CST716_WR_Reg(CST_ID_G_MODE,temp,1);		
	temp[0]=22;								
	CST716_WR_Reg(CST_ID_G_THGROUP,temp,1);	
	temp[0]=12;					
	CST716_WR_Reg(CST_ID_G_PERIODACTIVE,temp,1); 
	CST716_RD_Reg(CST_ID_G_LIB_VERSION,&temp[0],2);  
	if(temp[0]==0X30&&temp[1]==0X03)
	{ 
		printf("CTP ID:%x\r\n",((u16)temp[0]<<8)+temp[1]);
	} 
}
const u16 CST716_TPX_TBL[5]={0X03,0X09};
u8 g_gt_tnum=2; 


uint8_t CST716_Scanf(uint8_t mode)
{
	u8 buf[4];
	u8 i=0;
	u8 res=0;
	u8 temp;
    u16 tempsta;
	static u8 t=0; 
	t++;
    CST716_RD_Reg(CST_REG_NUM_FINGER,&mode,1);
        
		if((mode&0XF)&&((mode&0XF)<=g_gt_tnum))
		{
			temp=0XFF<<(mode&0XF);
			tempsta=tp_dev.sta;    
            tp_dev.sta=(~temp)|TP_PRES_DOWN|TP_CATH_PRES;
            tp_dev.x[g_gt_tnum-1]=tp_dev.x[0];
            tp_dev.y[g_gt_tnum-1]=tp_dev.y[0];

            delay_ms(4);   

			for(i=0;i<g_gt_tnum;i++)
			{
				if(tp_dev.sta&(1<<i))	
				{
					CST716_RD_Reg(CST716_TPX_TBL[i],buf,4);	
					if(tp_dev.touchtype&0X01)
					{
						tp_dev.y[i]=((u16)(buf[0]&0X0F)<<8)+buf[1];
						tp_dev.x[i]=(((u16)(buf[2]&0X0F)<<8)+buf[3]);
					}else
					{
						tp_dev.x[i]=(((u16)(buf[0]&0X0F)<<8)+buf[1]);
						tp_dev.y[i]=((u16)(buf[2]&0X0F)<<8)+buf[3];
					} 
                    
					printf("x[%d]:%d,y[%d]:%d\r\n",i,tp_dev.x[i],i,tp_dev.y[i]);
				}			
			} 
			res=1;
            if(tp_dev.x[0]>tftlcd_data.wigth||tp_dev.y[0]>tftlcd_data.height) 
            {
                if((mode&0XF)>1)   
                {
                    tp_dev.x[0]=tp_dev.x[1];
                    tp_dev.y[0]=tp_dev.y[1];
                    t=0; 
                }
                else       
                {
                    tp_dev.x[0]=tp_dev.x[g_gt_tnum-1];
                    tp_dev.y[0]=tp_dev.y[g_gt_tnum-1];
                    mode=0X80;
                    tp_dev.sta=tempsta;   
                }
            }
            else t=0;     
		}
	
 
	if((mode&0X1F)==0)
	{ 
		if(tp_dev.sta&TP_PRES_DOWN)
		{
			tp_dev.sta&=~TP_PRES_DOWN;	
		}else						
		{ 
			tp_dev.x[0]=0xffff;
			tp_dev.y[0]=0xffff;
			tp_dev.sta&=0XE0;
		}
	}
    
	if(t>240)t=10;
	return res;
}
















uint8_t  TP_Scanf(uint8_t tp){
	return  CST716_Scanf(0);
}
