#include<stm32f10x.h>
void TP_Init(void);
uint8_t CST716_Scanf(uint8_t mode);
uint8_t  TP_Scanf(uint8_t tp);
typedef struct
{
	void (*init)(void);			
	uint8_t (*scan)(uint8_t mode);
	void (*adjust)(void);		 
	u16 x[10]; 
	u16 y[10];	
	u16 sta;				 
	u8 touchtype;
}_m_tp_dev;

extern _m_tp_dev tp_dev;


#define CST_DEVIDE_MODE 		0x00   		
#define CST_REG_NUM_FINGER      0x02		

#define CST_TP1_REG 			0X03	  	
#define CST_TP2_REG 			0X09		
 
 
#define	CST_ID_G_LIB_VERSION	0xA1	
#define CST_ID_G_MODE 			0xA4   		
#define CST_ID_G_THGROUP		0x80   	
#define CST_ID_G_PERIODACTIVE	0x88   		

#define TP_PRES_DOWN 0x80  
#define TP_CATH_PRES 0x40  
#define CT_MAX_TOUCH 10    

#define CST_CMD_WR 				0X2A    	
#define CST_CMD_RD 				0X2B		